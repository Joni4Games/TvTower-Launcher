﻿Public Class Form3

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Shell("UpdateExe/TvTLU.exe", vbNormalFocus)
            End
        Catch ex As Exception
            MsgBox("Das Update-Programm wurde nicht gefunden! Bitte lade es erneut herunter!")
        End Try

    End Sub
End Class