﻿Imports System.Net
Imports System.IO
Imports System.IO.Compression
Imports System.Text
Imports System
Public Class Form1

    Dim logDirectoryProperties As System.IO.DirectoryInfo
    Dim WithEvents WC As New WebClient

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button1.Enabled = False
        If My.Computer.FileSystem.DirectoryExists("Exec\v036") Then
            Button1.Enabled = True
        End If
        ComboBox1.SelectedIndex = 0
        ComboBox2.SelectedIndex = 0
        Form2.Label1.Text = "Version " + My.Settings.Version
        My.Computer.FileSystem.CreateDirectory("Downs")
        My.Computer.FileSystem.CreateDirectory("Exec")

        Dim path As String = "curver.txt"
        Dim fs As FileStream = File.Create(path)
        Dim info As Byte() = New UTF8Encoding(True).GetBytes(My.Settings.Version)
        fs.Write(info, 0, info.Length)
        fs.Close()
        
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If ComboBox1.Text = "0.3.6" Then
            If My.Settings.launch = "32-Bit" Then
                Shell("exec\v036\TVTower_Win32.exe", vbNormalFocus)
            End If
            If My.Settings.launch = "64-Bit DirectX 7" Then
                MsgBox("64bitdx7")
                System.Diagnostics.Process.Start("exec\v036\TVTower_DirectX7.bat")
            End If
            If My.Settings.launch = "64-Bit DirectX 9" Then
                MsgBox("64bitdx9")
                System.Diagnostics.Process.Start("exec\v036\TVTower_DirectX9.bat")

            End If
            If My.Settings.launch = "64-Bit DirectX 11" Then
                MsgBox("64bitdx11")
                System.Diagnostics.Process.Start("exec\v036\TVTower_DirectX11.bat")

            End If
            If Form2.ComboBox1.Text = "64-Bit OpenGL" Then

            End If

        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If My.Computer.FileSystem.DirectoryExists("Downs") Then
StartHerunterladen:
            If ComboBox1.Text = "0.3.6" Then
                If My.Computer.FileSystem.FileExists("Downs\Downv036.zip") Then
                    MsgBox("Du besitzt bereits Version 0.3.6!", MsgBoxStyle.Information)
                Else
                    MsgBox("Version 0.3.6 wird herunterladen!")
                    My.Computer.FileSystem.CreateDirectory("Exec\v036")
                    WC.DownloadFileAsync(New Uri("https://github.com/GWRon/TVTower/releases/download/v0.3.6/TVTower_v0.3.6_20161224.zip"), "Downs\Downv036.zip")
                End If
            End If
        Else
            My.Computer.FileSystem.CreateDirectory("Downs")
            GoTo StartHerunterladen
        End If
    End Sub
    Private Sub WC_DownloadProgressChanged(ByVal sender As Object, ByVal e As DownloadProgressChangedEventArgs) Handles WC.DownloadProgressChanged
        ProgressBar1.Value = e.ProgressPercentage
        Label2.Text = e.ProgressPercentage
        If ProgressBar1.Value = 100 Then


        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim zip As New ZipLib.Zip
        If My.Computer.FileSystem.FileExists("ZipLib.dll") Then
            MsgBox("Die Spieldateien werden nun entpackt!")

            Try
                zip.unZipIT("Downs\Downv036.zip", "Exec\v036")
                Button1.Enabled = True

            Catch ex As Exception
                MsgBox("Ein Fehler ist beim Entpacken der Zip-Datei aufgetreten! Lösche diese und lade sie erneut herunter!")
            End Try

        Else
            MsgBox("Du benötigst die ZipLib.dll um Zip-Dateien entpacken zu können! Wir werden diese nun für dich herunterladen!")
            WC.DownloadFileAsync(New Uri("https://dl.dropboxusercontent.com/s/lhbjkfndnnpb1u7/ZipLib.dll?dl=1"), "ZipLib.dll")
        End If




    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Try
            My.Computer.FileSystem.DeleteDirectory("Downs",
               Microsoft.VisualBasic.FileIO.UIOption.AllDialogs,
               Microsoft.VisualBasic.FileIO.RecycleOption.DeletePermanently,
               Microsoft.VisualBasic.FileIO.UICancelOption.DoNothing)
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Try
            If My.Computer.FileSystem.FileExists("server.txt") Then
                My.Computer.FileSystem.DeleteFile("server.txt")
            End If
            'My.Computer.Network.DownloadFile("https://dl.dropboxusercontent.com/s/esnqjzttjypyva8/server.txt?dl=1", "server.txt")  --Server txt auf Dropbox
            My.Computer.Network.DownloadFile("http://www.friedofrenkel.com/TVTL/server", "server.txt")
            Dim serverRead As String
            serverRead = My.Computer.FileSystem.ReadAllText("server.txt")

            Dim curRead As String
            curRead = My.Computer.FileSystem.ReadAllText("curver.txt")
            MsgBox("Server-Version: " + serverRead + " | Client-Version: " + curRead, MsgBoxStyle.Information)
            If serverRead = curRead Then
                MsgBox("Dein Launcher ist Up-to-date!", MsgBoxStyle.Information)
            ElseIf serverRead > curRead Then
                MsgBox("Dein Launcher ist veraltet!", MsgBoxStyle.Critical)
                Form3.Show()
            End If
        Catch ex As Exception
            MsgBox("Ein Fehler ist beim Überprüfen der Version aufgetreten. Überprüfe deine Internetverbindung!")
        End Try
    End Sub
End Class
