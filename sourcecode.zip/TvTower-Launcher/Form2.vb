﻿Public Class Form2

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If My.Settings.launch = "leer" Then
            ComboBox1.Text = "Bitte auswählen!"
            ComboBox1.SelectedText = "Bitte auswählen!"
            ComboBox1.Refresh()
        End If
        ComboBox1.Text = My.Settings.launch
        Label5.Text = My.Settings.DateVersion
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        My.Settings.launch = ComboBox1.Text
        Label3.Text = ComboBox1.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Shell("explorer.exe Exec\v036\config", vbNormalFocus)
    End Sub
End Class