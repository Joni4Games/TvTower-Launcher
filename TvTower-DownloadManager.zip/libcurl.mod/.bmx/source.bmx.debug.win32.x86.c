#include "source.bmx.debug.win32.x86.h"
static int _bb_bah_libcurl_source_inited = 0;
int _bb_bah_libcurl_source(){
	if (!_bb_bah_libcurl_source_inited) {
		_bb_bah_libcurl_source_inited = 1;
		__bb_brl_blitz_blitz();
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_FUNCTION,
			"source",
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		bbOnDebugLeaveScope();
		return 0;
	}
	return 0;
}