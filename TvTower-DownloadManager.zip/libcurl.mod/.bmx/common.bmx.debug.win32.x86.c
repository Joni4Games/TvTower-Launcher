#include "common.bmx.debug.win32.x86.h"
struct BBDebugScope_1{int kind; const char *name; BBDebugDecl decls[2]; };
struct BBDebugScope_2{int kind; const char *name; BBDebugDecl decls[3]; };
struct BBDebugScope_3{int kind; const char *name; BBDebugDecl decls[4]; };
BBARRAY bah_libcurl_common_curlProcessSlist(BBBYTE* bbt_slistPtr){
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"curlProcessSlist",
		{
			{
				BBDEBUGDECL_LOCAL,
				"slistPtr",
				"*b",
				.var_address=&bbt_slistPtr
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 106, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(bbt_slistPtr){
		BBINT bbt_count=0;
		BBARRAY bbt_list=&bbEmptyArray;
		BBBYTE* bbt__struct=0;
		struct BBDebugScope_3 __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				{
					BBDEBUGDECL_LOCAL,
					"count",
					"i",
					.var_address=&bbt_count
				},
				{
					BBDEBUGDECL_LOCAL,
					"list",
					"[]$",
					.var_address=&bbt_list
				},
				{
					BBDEBUGDECL_LOCAL,
					"_struct",
					"*b",
					.var_address=&bbt__struct
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 108, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_count=bmx_curl_slist_count(bbt_slistPtr);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 109, 0};
		bbOnDebugEnterStm(&__stmt_1);
		bbt_list=bbArrayNew1D("$", bbt_count);
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 111, 0};
		bbOnDebugEnterStm(&__stmt_2);
		bbt__struct=bmx_curl_get_slist(bbt_slistPtr);
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 113, 0};
		bbOnDebugEnterStm(&__stmt_3);
		{
			BBINT bbt_i=0;
			BBINT bbt_=bbt_count;
			for(bbt_i;(bbt_i<bbt_);bbt_i=(bbt_i+1)){
				BBBYTE* bbt_s=0;
				struct BBDebugScope_2 __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						{
							BBDEBUGDECL_LOCAL,
							"i",
							"i",
							.var_address=&bbt_i
						},
						{
							BBDEBUGDECL_LOCAL,
							"s",
							"*b",
							.var_address=&bbt_s
						},
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 115, 0};
				bbOnDebugEnterStm(&__stmt_0);
				bbt_s=0;
				struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 117, 0};
				bbOnDebugEnterStm(&__stmt_1);
				bbt_s=bmx_curl_get_slist_data(bbt__struct);
				struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 119, 0};
				bbOnDebugEnterStm(&__stmt_2);
				if(bbt_s){
					struct BBDebugScope __scope = {
						BBDEBUGSCOPE_LOCALBLOCK,
						0,
						{
							BBDEBUGDECL_END 
						}
					};
					bbOnDebugEnterScope(&__scope);
					struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 121, 0};
					bbOnDebugEnterStm(&__stmt_0);
					((BBSTRING*)BBARRAYDATAINDEX((bbt_list),(bbt_list)->dims,((BBUINT)bbt_i)))[((BBUINT)bbt_i)]=bbStringFromCString(bbt_s);
					bbOnDebugLeaveScope();
				}
				struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 125, 0};
				bbOnDebugEnterStm(&__stmt_3);
				bbt__struct=bmx_curl_get_slist_next(bbt__struct);
				bbOnDebugLeaveScope();
			}
		}
		struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 129, 0};
		bbOnDebugEnterStm(&__stmt_4);
		bmx_curl_slist_free(bbt_slistPtr);
		struct BBDebugStm __stmt_5 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 131, 0};
		bbOnDebugEnterStm(&__stmt_5);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return bbArraySlice("$",bbt_list,0,bbt_count);
	}
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/common.bmx", 134, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbOnDebugLeaveScope();
	return &bbEmptyArray;
}
static int _bb_bah_libcurl_common_inited = 0;
int _bb_bah_libcurl_common(){
	if (!_bb_bah_libcurl_common_inited) {
		_bb_bah_libcurl_common_inited = 1;
		__bb_brl_blitz_blitz();
		__bb_pub_zlib_zlib();
		_bb_bah_libcurl_source();
		_bb_bah_libcurl_consts();
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_FUNCTION,
			"common",
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		bbOnDebugLeaveScope();
		return 0;
	}
	return 0;
}