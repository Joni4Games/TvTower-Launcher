#ifndef BAH_LIBCURL_LIBCURL_BMX_DEBUG_WIN32_X86_H
#define BAH_LIBCURL_LIBCURL_BMX_DEBUG_WIN32_X86_H

#include <brl.mod/blitz.mod/.bmx/blitz.bmx.debug.win32.x86.h>
#include "curlmain.bmx.debug.win32.x86.h"
int __bb_bah_libcurl_libcurl();

#endif
