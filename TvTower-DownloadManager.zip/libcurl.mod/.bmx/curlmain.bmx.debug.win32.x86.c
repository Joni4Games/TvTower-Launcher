#include "curlmain.bmx.debug.win32.x86.h"
struct BBDebugScope_1{int kind; const char *name; BBDebugDecl decls[2]; };
struct BBDebugScope_11{int kind; const char *name; BBDebugDecl decls[12]; };
struct BBDebugScope_12{int kind; const char *name; BBDebugDecl decls[13]; };
struct BBDebugScope_2{int kind; const char *name; BBDebugDecl decls[3]; };
struct BBDebugScope_3{int kind; const char *name; BBDebugDecl decls[4]; };
struct BBDebugScope_35{int kind; const char *name; BBDebugDecl decls[36]; };
struct BBDebugScope_4{int kind; const char *name; BBDebugDecl decls[5]; };
struct BBDebugScope_5{int kind; const char *name; BBDebugDecl decls[6]; };
struct BBDebugScope_50{int kind; const char *name; BBDebugDecl decls[51]; };
struct BBDebugScope_8{int kind; const char *name; BBDebugDecl decls[9]; };
void _bah_libcurl_curlmain_TCurlHasLists_New(struct bah_libcurl_curlmain_TCurlHasLists_obj* o) {
	bbObjectCtor(o);
	o->clas = (BBClass*)&bah_libcurl_curlmain_TCurlHasLists;
	((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists = &bbEmptyArray;
}
void _bah_libcurl_curlmain_TCurlHasLists_freeLists(struct bah_libcurl_curlmain_TCurlHasLists_obj* o){
	((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"freeLists",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlHasLists",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 63, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists != &bbEmptyArray){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 65, 0};
		bbOnDebugEnterStm(&__stmt_0);
		{
			BBINT bbt_i=0;
			BBINT bbt_=(((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists ->scales[0]);
			for(bbt_i;(bbt_i<bbt_);bbt_i=(bbt_i+1)){
				struct BBDebugScope_1 __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						{
							BBDEBUGDECL_LOCAL,
							"i",
							"i",
							.var_address=&bbt_i
						},
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 67, 0};
				bbOnDebugEnterStm(&__stmt_0);
				bmx_curl_slist_free(((BBBYTE**)BBARRAYDATAINDEX((((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists ),(((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists )->dims,((BBUINT)bbt_i)))[((BBUINT)bbt_i)]);
				bbOnDebugLeaveScope();
			}
		}
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 71, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists =&bbEmptyArray;
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
struct BBDebugScope_3 bah_libcurl_curlmain_TCurlHasLists_scope ={
	BBDEBUGSCOPE_USERTYPE,
	"TCurlHasLists",
	{
		{
			BBDEBUGDECL_FIELD,
			"sLists",
			"[]*b",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlHasLists_obj,_bah_libcurl_curlmain_tcurlhaslists_slists)
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"New",
			"()",
			&_bah_libcurl_curlmain_TCurlHasLists_New
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"freeLists",
			"()",
			&_bah_libcurl_curlmain_TCurlHasLists_freeLists
		},
		BBDEBUGDECL_END
	}
};
struct BBClass_bah_libcurl_curlmain_TCurlHasLists bah_libcurl_curlmain_TCurlHasLists={
	&bbObjectClass,
	bbObjectFree,
	&bah_libcurl_curlmain_TCurlHasLists_scope,
	sizeof(struct bah_libcurl_curlmain_TCurlHasLists_obj),
	_bah_libcurl_curlmain_TCurlHasLists_New,
	bbObjectDtor,
	bbObjectToString,
	bbObjectCompare,
	bbObjectSendMessage,
	0,
	0,
	offsetof(struct bah_libcurl_curlmain_TCurlHasLists_obj,_bah_libcurl_curlmain_tcurlhaslists_slists) - sizeof(void*) + sizeof(BBARRAY)
	,_bah_libcurl_curlmain_TCurlHasLists_freeLists
};

void _bah_libcurl_curlmain_TCurlEasy_New(struct bah_libcurl_curlmain_TCurlEasy_obj* o) {
	_bah_libcurl_curlmain_TCurlHasLists_New(o);
	o->clas = (BBClass*)&bah_libcurl_curlmain_TCurlEasy;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr = 0;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap = bbObjectNew(&brl_map_TMap);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_data = &bbEmptyString;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_dbdata = &bbNullObject;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_dbfunction = &brl_blitz_NullFunctionError;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_wrdata = &bbNullObject;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_wrfunction = &brl_blitz_NullFunctionError;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_rddata = &bbNullObject;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_rdfunction = &brl_blitz_NullFunctionError;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_hrdata = &bbNullObject;
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_hrfunction = &brl_blitz_NullFunctionError;
}
void _bah_libcurl_curlmain_TCurlEasy_Delete(struct bah_libcurl_curlmain_TCurlEasy_obj* o) {
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"Delete",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 739, 0};
	bbOnDebugEnterStm(&__stmt_0);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_cleanup(o);
	bbOnDebugLeaveScope();
	BBRELEASE(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_data )
	bbObjectDtor(o);
}
struct bah_libcurl_curlmain_TCurlEasy_obj* bah_libcurl_curlmain_TCurlEasy_Create_TTCurlEasy(){
	struct bah_libcurl_curlmain_TCurlEasy_obj* volatile bbt_this=&bbNullObject;
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"Create",
		{
			{
				BBDEBUGDECL_LOCAL,
				"this",
				":TCurlEasy",
				.var_address=&bbt_this
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 117, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_this=bbObjectNew(&bah_libcurl_curlmain_TCurlEasy);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 119, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_this))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr =curl_easy_init();
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 121, 0};
	bbOnDebugEnterStm(&__stmt_2);
	if(!(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_this))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr )){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 122, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return &bbNullObject;
	}
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 125, 0};
	bbOnDebugEnterStm(&__stmt_3);
	bbOnDebugLeaveScope();
	return bbt_this;
}
void _bah_libcurl_curlmain_TCurlEasy_setOpt_ipb(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT bbt_option,BBBYTE* bbt_parameter){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setOpt",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"option",
				"i",
				.var_address=&bbt_option
			},
			{
				BBDEBUGDECL_LOCAL,
				"parameter",
				"*b",
				.var_address=&bbt_parameter
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 130, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 131, 0};
		bbOnDebugEnterStm(&__stmt_0);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_option,bbt_parameter);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_setPrivate_TObject(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBOBJECT bbt_data){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setPrivate",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 144, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 145, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_easy_setopt_obj(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10103,bbt_data);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_setOptInt_ii(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT bbt_option,BBINT bbt_parameter){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setOptInt",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"option",
				"i",
				.var_address=&bbt_option
			},
			{
				BBDEBUGDECL_LOCAL,
				"parameter",
				"i",
				.var_address=&bbt_parameter
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 153, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 154, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_easy_setopt_long(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_option,bbt_parameter);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_setOptLong_il(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT bbt_option,BBLONG bbt_parameter){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setOptLong",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"option",
				"i",
				.var_address=&bbt_option
			},
			{
				BBDEBUGDECL_LOCAL,
				"parameter",
				"l",
				.var_address=&bbt_parameter
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 162, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 163, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_easy_setopt_bbint64(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_option,bbt_parameter);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_setOptBytePtr_ipb(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT bbt_option,BBBYTE* bbt_parameter){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setOptBytePtr",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"option",
				"i",
				.var_address=&bbt_option
			},
			{
				BBDEBUGDECL_LOCAL,
				"parameter",
				"*b",
				.var_address=&bbt_parameter
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 171, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 172, 0};
		bbOnDebugEnterStm(&__stmt_0);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_option,bbt_parameter);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_setOptString_iS(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT bbt_option,BBSTRING bbt_parameter){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setOptString",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"option",
				"i",
				.var_address=&bbt_option
			},
			{
				BBDEBUGDECL_LOCAL,
				"parameter",
				"$",
				.var_address=&bbt_parameter
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 180, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		BBBYTE* bbt_s=0;
		struct bah_libcurl_curlmain_TCurlInt_obj* volatile bbt_opt=&bbNullObject;
		struct BBDebugScope_2 __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				{
					BBDEBUGDECL_LOCAL,
					"s",
					"*b",
					.var_address=&bbt_s
				},
				{
					BBDEBUGDECL_LOCAL,
					"opt",
					":TCurlInt",
					.var_address=&bbt_opt
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 183, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_s=0;
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 184, 0};
		bbOnDebugEnterStm(&__stmt_1);
		bbt_opt=((struct bah_libcurl_curlmain_TCurlInt_obj*)bbObjectDowncast((((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap )->clas->m_ValueForKey_TObject(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap ,bbStringFromInt(bbt_option)),&bah_libcurl_curlmain_TCurlInt));
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 186, 0};
		bbOnDebugEnterStm(&__stmt_2);
		if(bbt_opt!= &bbNullObject){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 188, 0};
			bbOnDebugEnterStm(&__stmt_0);
			if(((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_opt))->_bah_libcurl_curlmain_tcurlint_s ){
				struct BBDebugScope __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 189, 0};
				bbOnDebugEnterStm(&__stmt_0);
				bbMemFree((void*)((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_opt))->_bah_libcurl_curlmain_tcurlint_s );
				bbOnDebugLeaveScope();
			}
			bbOnDebugLeaveScope();
		}else{
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 192, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bbt_opt=bbObjectAtomicNew(&bah_libcurl_curlmain_TCurlInt);
			struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 193, 0};
			bbOnDebugEnterStm(&__stmt_1);
			((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_opt))->_bah_libcurl_curlmain_tcurlint_opt =bbt_option;
			struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 194, 0};
			bbOnDebugEnterStm(&__stmt_2);
			(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap )->clas->m_Insert_TObjectTObject(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap ,bbStringFromInt(bbt_option),bbt_opt);
			bbOnDebugLeaveScope();
		}
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 197, 0};
		bbOnDebugEnterStm(&__stmt_3);
		if(bbt_parameter!= &bbEmptyString){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 198, 0};
			bbOnDebugEnterStm(&__stmt_0);
			((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_opt))->_bah_libcurl_curlmain_tcurlint_s =bbStringToCString(bbt_parameter);
			struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 199, 0};
			bbOnDebugEnterStm(&__stmt_1);
			curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_option,((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_opt))->_bah_libcurl_curlmain_tcurlint_s );
			bbOnDebugLeaveScope();
		}else{
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 201, 0};
			bbOnDebugEnterStm(&__stmt_0);
			((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_opt))->_bah_libcurl_curlmain_tcurlint_s =0;
			struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 202, 0};
			bbOnDebugEnterStm(&__stmt_1);
			curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_option,0);
			bbOnDebugLeaveScope();
		}
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
BBINT _bah_libcurl_curlmain_TCurlEasy_perform(struct bah_libcurl_curlmain_TCurlEasy_obj* o){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"perform",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 217, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 218, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return curl_easy_perform(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr );
	}
	bbOnDebugLeaveScope();
	return 0;
}
void _bah_libcurl_curlmain_TCurlEasy_cleanup(struct bah_libcurl_curlmain_TCurlEasy_obj* o){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"cleanup",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 233, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 234, 0};
		bbOnDebugEnterStm(&__stmt_0);
		curl_easy_cleanup(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr );
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 235, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr =0;
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 239, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_freeLists(o);
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 242, 0};
	bbOnDebugEnterStm(&__stmt_2);
	struct brl_map_TMapEnumerator_obj* volatile bbt_=(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap )->clas->m_Values(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap );
	struct brl_map_TNodeEnumerator_obj* volatile bbt_2=(bbt_)->clas->m_ObjectEnumerator(bbt_);
	while((bbt_2)->clas->m_HasNext(bbt_2)!=0){
		struct bah_libcurl_curlmain_TCurlInt_obj* volatile bbt_i=&bbNullObject;
		struct BBDebugScope_1 __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				{
					BBDEBUGDECL_LOCAL,
					"i",
					":TCurlInt",
					.var_address=&bbt_i
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		bbt_i=((struct bah_libcurl_curlmain_TCurlInt_obj*)bbObjectDowncast((bbt_2)->clas->m_NextObject(bbt_2),&bah_libcurl_curlmain_TCurlInt));
		if(bbt_i==&bbNullObject){
			bbOnDebugLeaveScope();
			continue;
		}
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 244, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbMemFree((void*)((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_i))->_bah_libcurl_curlmain_tcurlint_s );
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 247, 0};
	bbOnDebugEnterStm(&__stmt_3);
	(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap )->clas->m_Clear(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_stringmap );
	struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 250, 0};
	bbOnDebugEnterStm(&__stmt_4);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_dbdata =&bbNullObject;
	struct BBDebugStm __stmt_5 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 251, 0};
	bbOnDebugEnterStm(&__stmt_5);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_dbfunction =&brl_blitz_NullFunctionError;
	struct BBDebugStm __stmt_6 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 252, 0};
	bbOnDebugEnterStm(&__stmt_6);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_wrdata =&bbNullObject;
	struct BBDebugStm __stmt_7 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 253, 0};
	bbOnDebugEnterStm(&__stmt_7);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_wrfunction =&brl_blitz_NullFunctionError;
	struct BBDebugStm __stmt_8 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 254, 0};
	bbOnDebugEnterStm(&__stmt_8);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_rddata =&bbNullObject;
	struct BBDebugStm __stmt_9 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 255, 0};
	bbOnDebugEnterStm(&__stmt_9);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_rdfunction =&brl_blitz_NullFunctionError;
	struct BBDebugStm __stmt_10 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 256, 0};
	bbOnDebugEnterStm(&__stmt_10);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_hrdata =&bbNullObject;
	struct BBDebugStm __stmt_11 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 257, 0};
	bbOnDebugEnterStm(&__stmt_11);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_hrfunction =&brl_blitz_NullFunctionError;
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_reset(struct bah_libcurl_curlmain_TCurlEasy_obj* o){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"reset",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 269, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 270, 0};
		bbOnDebugEnterStm(&__stmt_0);
		curl_easy_reset(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr );
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_setProgressCallback_F_TObjectdddd_i_TObject(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT(* bbt_progressFunction)(BBOBJECT,BBDOUBLE,BBDOUBLE,BBDOUBLE,BBDOUBLE),BBOBJECT bbt_data){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setProgressCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"progressFunction",
				"(:Object,d,d,d,d)i",
				.var_address=&bbt_progressFunction
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 289, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 291, 0};
		bbOnDebugEnterStm(&__stmt_0);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_setOptInt_ii(o,43,0);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 294, 0};
		bbOnDebugEnterStm(&__stmt_1);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,20056,bbt_progressFunction);
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 297, 0};
		bbOnDebugEnterStm(&__stmt_2);
		if(bbt_data!= &bbNullObject){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 298, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bmx_curl_easy_setopt_obj(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10057,bbt_data);
			bbOnDebugLeaveScope();
		}
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_setDebugCallback_F_TObjectiS_i_TObject(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT(* bbt_debugFunction)(BBOBJECT,BBINT,BBSTRING),BBOBJECT bbt_data){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setDebugCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"debugFunction",
				"(:Object,i,$)i",
				.var_address=&bbt_debugFunction
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 314, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 316, 0};
		bbOnDebugEnterStm(&__stmt_0);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_dbfunction =bbt_debugFunction;
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 317, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_dbdata =bbt_data;
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 319, 0};
		bbOnDebugEnterStm(&__stmt_2);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,20094,bah_libcurl_curlmain_TCurlEasy_dbCallback_i_pbipbiTObject);
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 320, 0};
		bbOnDebugEnterStm(&__stmt_3);
		bmx_curl_easy_setopt_obj(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10095,o);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
BBINT bah_libcurl_curlmain_TCurlEasy_dbCallback_i_pbipbiTObject(BBBYTE* bbt_handle,BBINT bbt_infotype,BBBYTE* bbt_msg,BBINT bbt_size,BBOBJECT bbt_data){
	struct BBDebugScope_5 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"dbCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"handle",
				"*b",
				.var_address=&bbt_handle
			},
			{
				BBDEBUGDECL_LOCAL,
				"infotype",
				"i",
				.var_address=&bbt_infotype
			},
			{
				BBDEBUGDECL_LOCAL,
				"msg",
				"*b",
				.var_address=&bbt_msg
			},
			{
				BBDEBUGDECL_LOCAL,
				"size",
				"i",
				.var_address=&bbt_size
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 330, 0};
	bbOnDebugEnterStm(&__stmt_0);
	struct bah_libcurl_curlmain_TCurlEasy_obj* bbt_;
	bbOnDebugLeaveScope();
	return ((struct bah_libcurl_curlmain_TCurlEasy_obj*)((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_data,&bah_libcurl_curlmain_TCurlEasy)))->_bah_libcurl_curlmain_tcurleasy_dbfunction(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_data,&bah_libcurl_curlmain_TCurlEasy))))->_bah_libcurl_curlmain_tcurleasy_dbdata ,bbt_infotype,bbStringFromBytes(bbt_msg,bbt_size));
}
void _bah_libcurl_curlmain_TCurlEasy_setWriteStream_TTStream(struct bah_libcurl_curlmain_TCurlEasy_obj* o,struct brl_stream_TStream_obj* bbt_stream){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setWriteStream",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"stream",
				":TStream",
				.var_address=&bbt_stream
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 340, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 342, 0};
		bbOnDebugEnterStm(&__stmt_0);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,20011,bah_libcurl_curlmain_TCurlEasy_writeStreamCallback_i_pbiiTObject);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 343, 0};
		bbOnDebugEnterStm(&__stmt_1);
		bmx_curl_easy_setopt_obj(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10001,bbt_stream);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
BBINT bah_libcurl_curlmain_TCurlEasy_writeStreamCallback_i_pbiiTObject(BBBYTE* bbt_buffer,BBINT bbt_size,BBINT bbt_nmemb,BBOBJECT bbt_stream){
	struct BBDebugScope_4 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"writeStreamCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"buffer",
				"*b",
				.var_address=&bbt_buffer
			},
			{
				BBDEBUGDECL_LOCAL,
				"size",
				"i",
				.var_address=&bbt_size
			},
			{
				BBDEBUGDECL_LOCAL,
				"nmemb",
				"i",
				.var_address=&bbt_nmemb
			},
			{
				BBDEBUGDECL_LOCAL,
				"stream",
				":Object",
				.var_address=&bbt_stream
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 350, 0};
	bbOnDebugEnterStm(&__stmt_0);
	struct brl_stream_TStream_obj* bbt_;
	bbOnDebugLeaveScope();
	return ((BBINT)(((struct brl_stream_TStream_obj*)((struct brl_stream_TStream_obj*)bbNullObjectTest((bbt_ = ((struct brl_stream_TStream_obj*)bbObjectDowncast(bbt_stream,&brl_stream_TStream))))))->clas)->m_WriteBytes_pbl(bbt_,bbt_buffer,((BBLONG)(bbt_size*bbt_nmemb))));
}
void _bah_libcurl_curlmain_TCurlEasy_setWriteCallback_F_pbiTObject_i_TObject(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT(* bbt_writeFunction)(BBBYTE*,BBINT,BBOBJECT),BBOBJECT bbt_data){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setWriteCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"writeFunction",
				"(*b,i,:Object)i",
				.var_address=&bbt_writeFunction
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 366, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 368, 0};
		bbOnDebugEnterStm(&__stmt_0);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_wrfunction =bbt_writeFunction;
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 369, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_wrdata =bbt_data;
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 371, 0};
		bbOnDebugEnterStm(&__stmt_2);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,20011,bah_libcurl_curlmain_TCurlEasy_wrCallback_i_pbiiTObject);
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 372, 0};
		bbOnDebugEnterStm(&__stmt_3);
		bmx_curl_easy_setopt_obj(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10001,o);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
BBINT bah_libcurl_curlmain_TCurlEasy_wrCallback_i_pbiiTObject(BBBYTE* bbt_buffer,BBINT bbt_size,BBINT bbt_nmemb,BBOBJECT bbt_data){
	struct BBDebugScope_4 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"wrCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"buffer",
				"*b",
				.var_address=&bbt_buffer
			},
			{
				BBDEBUGDECL_LOCAL,
				"size",
				"i",
				.var_address=&bbt_size
			},
			{
				BBDEBUGDECL_LOCAL,
				"nmemb",
				"i",
				.var_address=&bbt_nmemb
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 382, 0};
	bbOnDebugEnterStm(&__stmt_0);
	struct bah_libcurl_curlmain_TCurlEasy_obj* bbt_;
	bbOnDebugLeaveScope();
	return ((struct bah_libcurl_curlmain_TCurlEasy_obj*)((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_data,&bah_libcurl_curlmain_TCurlEasy)))->_bah_libcurl_curlmain_tcurleasy_wrfunction(bbt_buffer,(bbt_size*bbt_nmemb),((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_data,&bah_libcurl_curlmain_TCurlEasy))))->_bah_libcurl_curlmain_tcurleasy_wrdata );
}
void _bah_libcurl_curlmain_TCurlEasy_setWriteString(struct bah_libcurl_curlmain_TCurlEasy_obj* o){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setWriteString",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 393, 0};
	bbOnDebugEnterStm(&__stmt_0);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_data =&bbEmptyString;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 394, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_setWriteCallback_F_pbiTObject_i_TObject(o,o->clas->f_writeStringFunction_i_pbiTObject,o);
	bbOnDebugLeaveScope();
}
BBINT bah_libcurl_curlmain_TCurlEasy_writeStringFunction_i_pbiTObject(BBBYTE* bbt_buffer,BBINT bbt_size,BBOBJECT bbt_curl){
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"writeStringFunction",
		{
			{
				BBDEBUGDECL_LOCAL,
				"buffer",
				"*b",
				.var_address=&bbt_buffer
			},
			{
				BBDEBUGDECL_LOCAL,
				"size",
				"i",
				.var_address=&bbt_size
			},
			{
				BBDEBUGDECL_LOCAL,
				"curl",
				":Object",
				.var_address=&bbt_curl
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 398, 0};
	bbOnDebugEnterStm(&__stmt_0);
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_curl,&bah_libcurl_curlmain_TCurlEasy))))->_bah_libcurl_curlmain_tcurleasy_data =bbStringConcat(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_curl,&bah_libcurl_curlmain_TCurlEasy))))->_bah_libcurl_curlmain_tcurleasy_data ,bbStringFromBytes(bbt_buffer,bbt_size));
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 399, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbOnDebugLeaveScope();
	return bbt_size;
}
void _bah_libcurl_curlmain_TCurlEasy_setReadStream_TTStream(struct bah_libcurl_curlmain_TCurlEasy_obj* o,struct brl_stream_TStream_obj* bbt_stream){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setReadStream",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"stream",
				":TStream",
				.var_address=&bbt_stream
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 407, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 409, 0};
		bbOnDebugEnterStm(&__stmt_0);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,20012,bah_libcurl_curlmain_TCurlEasy_readStreamCallback_i_pbiiTObject);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 410, 0};
		bbOnDebugEnterStm(&__stmt_1);
		bmx_curl_easy_setopt_obj(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10009,bbt_stream);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
BBINT bah_libcurl_curlmain_TCurlEasy_readStreamCallback_i_pbiiTObject(BBBYTE* bbt_buffer,BBINT bbt_size,BBINT bbt_nmemb,BBOBJECT bbt_stream){
	struct BBDebugScope_4 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"readStreamCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"buffer",
				"*b",
				.var_address=&bbt_buffer
			},
			{
				BBDEBUGDECL_LOCAL,
				"size",
				"i",
				.var_address=&bbt_size
			},
			{
				BBDEBUGDECL_LOCAL,
				"nmemb",
				"i",
				.var_address=&bbt_nmemb
			},
			{
				BBDEBUGDECL_LOCAL,
				"stream",
				":Object",
				.var_address=&bbt_stream
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 416, 0};
	bbOnDebugEnterStm(&__stmt_0);
	do {
		jmp_buf * buf = bbExEnter();
		switch(setjmp(*buf)) {
			case 0: {
				bbOnDebugPushExState();
				struct BBDebugScope __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 417, 0};
				bbOnDebugEnterStm(&__stmt_0);
				struct brl_stream_TStream_obj* bbt_2;
				BBLONG bbt_=(((struct brl_stream_TStream_obj*)((struct brl_stream_TStream_obj*)bbNullObjectTest((bbt_2 = ((struct brl_stream_TStream_obj*)bbObjectDowncast(bbt_stream,&brl_stream_TStream))))))->clas)->m_Read_pbl(bbt_2,bbt_buffer,((BBLONG)(bbt_size*bbt_nmemb)));
				bbOnDebugLeaveScope();
				bbOnDebugLeaveScope();
				bbExLeave();
				bbOnDebugPopExState();
				return ((BBINT)bbt_);
				bbExLeave();
				bbOnDebugPopExState();
			}
			break;
			case 1:
			{
				bbOnDebugPopExState();
				BBOBJECT ex = bbExObject();
				if (bbObjectDowncast(ex,&brl_stream_TStreamReadException) != &bbNullObject) {
					struct brl_stream_TStreamReadException_obj* bbt_e=(struct brl_stream_TStreamReadException_obj*)ex;
					struct BBDebugScope_1 __scope = {
						BBDEBUGSCOPE_LOCALBLOCK,
						0,
						{
							{
								BBDEBUGDECL_LOCAL,
								"e",
								":TStreamReadException",
								.var_address=&bbt_e
							},
							BBDEBUGDECL_END 
						}
					};
					bbOnDebugEnterScope(&__scope);
					struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 419, 0};
					bbOnDebugEnterStm(&__stmt_0);
					bbOnDebugLeaveScope();
					bbOnDebugLeaveScope();
					return 268435456;
				} else  {
					bbExThrow(ex);
				}
			}
			break;
		}
	} while(0);
	bbOnDebugLeaveScope();
	return 0;
}
void _bah_libcurl_curlmain_TCurlEasy_setReadCallback_F_pbiTObject_i_TObject(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT(* bbt_readFunction)(BBBYTE*,BBINT,BBOBJECT),BBOBJECT bbt_data){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setReadCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"readFunction",
				"(*b,i,:Object)i",
				.var_address=&bbt_readFunction
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 441, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 443, 0};
		bbOnDebugEnterStm(&__stmt_0);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_rdfunction =bbt_readFunction;
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 444, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_rddata =bbt_data;
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 446, 0};
		bbOnDebugEnterStm(&__stmt_2);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,20012,bah_libcurl_curlmain_TCurlEasy_rdCallback_i_pbiiTObject);
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 447, 0};
		bbOnDebugEnterStm(&__stmt_3);
		bmx_curl_easy_setopt_obj(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10009,o);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
BBINT bah_libcurl_curlmain_TCurlEasy_rdCallback_i_pbiiTObject(BBBYTE* bbt_buffer,BBINT bbt_size,BBINT bbt_nmemb,BBOBJECT bbt_data){
	struct BBDebugScope_4 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"rdCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"buffer",
				"*b",
				.var_address=&bbt_buffer
			},
			{
				BBDEBUGDECL_LOCAL,
				"size",
				"i",
				.var_address=&bbt_size
			},
			{
				BBDEBUGDECL_LOCAL,
				"nmemb",
				"i",
				.var_address=&bbt_nmemb
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 457, 0};
	bbOnDebugEnterStm(&__stmt_0);
	struct bah_libcurl_curlmain_TCurlEasy_obj* bbt_;
	bbOnDebugLeaveScope();
	return ((struct bah_libcurl_curlmain_TCurlEasy_obj*)((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_data,&bah_libcurl_curlmain_TCurlEasy)))->_bah_libcurl_curlmain_tcurleasy_rdfunction(bbt_buffer,(bbt_size*bbt_nmemb),((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_data,&bah_libcurl_curlmain_TCurlEasy))))->_bah_libcurl_curlmain_tcurleasy_rddata );
}
void _bah_libcurl_curlmain_TCurlEasy_setHeaderCallback_F_pbiTObject_i_TObject(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT(* bbt_headerFunction)(BBBYTE*,BBINT,BBOBJECT),BBOBJECT bbt_data){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"setHeaderCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"headerFunction",
				"(*b,i,:Object)i",
				.var_address=&bbt_headerFunction
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 481, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 483, 0};
		bbOnDebugEnterStm(&__stmt_0);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_hrfunction =bbt_headerFunction;
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 484, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_hrdata =bbt_data;
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 486, 0};
		bbOnDebugEnterStm(&__stmt_2);
		curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,20079,bah_libcurl_curlmain_TCurlEasy_hrCallback_i_pbiiTObject);
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 487, 0};
		bbOnDebugEnterStm(&__stmt_3);
		bmx_curl_easy_setopt_obj(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10029,o);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
BBINT bah_libcurl_curlmain_TCurlEasy_hrCallback_i_pbiiTObject(BBBYTE* bbt_buffer,BBINT bbt_size,BBINT bbt_nmemb,BBOBJECT bbt_data){
	struct BBDebugScope_4 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"hrCallback",
		{
			{
				BBDEBUGDECL_LOCAL,
				"buffer",
				"*b",
				.var_address=&bbt_buffer
			},
			{
				BBDEBUGDECL_LOCAL,
				"size",
				"i",
				.var_address=&bbt_size
			},
			{
				BBDEBUGDECL_LOCAL,
				"nmemb",
				"i",
				.var_address=&bbt_nmemb
			},
			{
				BBDEBUGDECL_LOCAL,
				"data",
				":Object",
				.var_address=&bbt_data
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 497, 0};
	bbOnDebugEnterStm(&__stmt_0);
	struct bah_libcurl_curlmain_TCurlEasy_obj* bbt_;
	bbOnDebugLeaveScope();
	return ((struct bah_libcurl_curlmain_TCurlEasy_obj*)((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_data,&bah_libcurl_curlmain_TCurlEasy)))->_bah_libcurl_curlmain_tcurleasy_hrfunction(bbt_buffer,(bbt_size*bbt_nmemb),((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast(bbt_data,&bah_libcurl_curlmain_TCurlEasy))))->_bah_libcurl_curlmain_tcurleasy_hrdata );
}
void _bah_libcurl_curlmain_TCurlEasy_httpPost_TTCurlFormData(struct bah_libcurl_curlmain_TCurlEasy_obj* o,struct bah_libcurl_curlmain_TCurlFormData_obj* bbt_formData){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"httpPost",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"formData",
				":TCurlFormData",
				.var_address=&bbt_formData
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 514, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 515, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_easy_setopt_httppost(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(bbt_formData))->_bah_libcurl_curlmain_tcurlformdata_httppostptr );
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_httpHeader_aS(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBARRAY bbt_headers){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"httpHeader",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"headers",
				"[]$",
				.var_address=&bbt_headers
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 542, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 543, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(bbt_headers!= &bbEmptyArray){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 544, 0};
			bbOnDebugEnterStm(&__stmt_0);
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_processArray_iaS(o,10023,bbt_headers);
			bbOnDebugLeaveScope();
		}else{
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 546, 0};
			bbOnDebugEnterStm(&__stmt_0);
			curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10023,0);
			bbOnDebugLeaveScope();
		}
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_http200Aliases_aS(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBARRAY bbt_aliases){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"http200Aliases",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"aliases",
				"[]$",
				.var_address=&bbt_aliases
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 564, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 565, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(bbt_aliases!= &bbEmptyArray){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 566, 0};
			bbOnDebugEnterStm(&__stmt_0);
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_processArray_iaS(o,10104,bbt_aliases);
			bbOnDebugLeaveScope();
		}else{
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 568, 0};
			bbOnDebugEnterStm(&__stmt_0);
			curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10104,0);
			bbOnDebugLeaveScope();
		}
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_preQuote_aS(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBARRAY bbt_commands){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"preQuote",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"commands",
				"[]$",
				.var_address=&bbt_commands
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 580, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 581, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(bbt_commands!= &bbEmptyArray){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 582, 0};
			bbOnDebugEnterStm(&__stmt_0);
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_processArray_iaS(o,10093,bbt_commands);
			bbOnDebugLeaveScope();
		}else{
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 584, 0};
			bbOnDebugEnterStm(&__stmt_0);
			curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10093,0);
			bbOnDebugLeaveScope();
		}
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_quote_aS(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBARRAY bbt_commands){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"quote",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"commands",
				"[]$",
				.var_address=&bbt_commands
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 598, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 599, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(bbt_commands!= &bbEmptyArray){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 600, 0};
			bbOnDebugEnterStm(&__stmt_0);
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_processArray_iaS(o,10028,bbt_commands);
			bbOnDebugLeaveScope();
		}else{
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 602, 0};
			bbOnDebugEnterStm(&__stmt_0);
			curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10028,0);
			bbOnDebugLeaveScope();
		}
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_postQuote_aS(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBARRAY bbt_commands){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"postQuote",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"commands",
				"[]$",
				.var_address=&bbt_commands
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 614, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 615, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(bbt_commands!= &bbEmptyArray){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 616, 0};
			bbOnDebugEnterStm(&__stmt_0);
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_processArray_iaS(o,10039,bbt_commands);
			bbOnDebugLeaveScope();
		}else{
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 618, 0};
			bbOnDebugEnterStm(&__stmt_0);
			curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10039,0);
			bbOnDebugLeaveScope();
		}
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlEasy_telnetOptions_aS(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBARRAY bbt_variables){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"telnetOptions",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"variables",
				"[]$",
				.var_address=&bbt_variables
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 631, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 632, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(bbt_variables!= &bbEmptyArray){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 633, 0};
			bbOnDebugEnterStm(&__stmt_0);
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
			((struct bah_libcurl_curlmain_TCurlEasy_obj*)o)->clas->m_processArray_iaS(o,10070,bbt_variables);
			bbOnDebugLeaveScope();
		}else{
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 635, 0};
			bbOnDebugEnterStm(&__stmt_0);
			curl_easy_setopt(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,10070,0);
			bbOnDebugLeaveScope();
		}
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
struct bah_libcurl_curlmain_TCurlInfo_obj* _bah_libcurl_curlmain_TCurlEasy_getInfo(struct bah_libcurl_curlmain_TCurlEasy_obj* o){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"getInfo",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 645, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 646, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return bah_libcurl_curlmain_TCurlInfo__create_TTCurlInfo_pb(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr );
	}
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 648, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbOnDebugLeaveScope();
	return &bbNullObject;
}
void _bah_libcurl_curlmain_TCurlEasy_freeLists(struct bah_libcurl_curlmain_TCurlEasy_obj* o){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"freeLists",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 661, 0};
	bbOnDebugEnterStm(&__stmt_0);
	(&bah_libcurl_curlmain_TCurlEasy)->super->m_freeLists(o);
	bbOnDebugLeaveScope();
}
BBSTRING _bah_libcurl_curlmain_TCurlEasy_escape_S(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBSTRING bbt_Text){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"escape",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"Text",
				"$",
				.var_address=&bbt_Text
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 671, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		BBBYTE* bbt_s=0;
		BBBYTE* bbt_s2=0;
		struct BBDebugScope_2 __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				{
					BBDEBUGDECL_LOCAL,
					"s",
					"*b",
					.var_address=&bbt_s
				},
				{
					BBDEBUGDECL_LOCAL,
					"s2",
					"*b",
					.var_address=&bbt_s2
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 672, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(!(bbt_Text!= &bbEmptyString)){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 673, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bbt_Text=&bbEmptyString;
			bbOnDebugLeaveScope();
		}
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 676, 0};
		bbOnDebugEnterStm(&__stmt_1);
		bbt_s=bbStringToCString(bbt_Text);
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 678, 0};
		bbOnDebugEnterStm(&__stmt_2);
		bbt_s2=curl_easy_escape(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_s,(bbt_Text->length));
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 681, 0};
		bbOnDebugEnterStm(&__stmt_3);
		bbMemFree((void*)bbt_s);
		struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 683, 0};
		bbOnDebugEnterStm(&__stmt_4);
		if(bbt_s2){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 685, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bbt_Text=bbStringFromCString(bbt_s2);
			struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 688, 0};
			bbOnDebugEnterStm(&__stmt_1);
			curl_free(bbt_s2);
			struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 690, 0};
			bbOnDebugEnterStm(&__stmt_2);
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			return bbt_Text;
		}
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 694, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbOnDebugLeaveScope();
	return &bbEmptyString;
}
BBSTRING _bah_libcurl_curlmain_TCurlEasy_unEscape_S(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBSTRING bbt_Text){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"unEscape",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"Text",
				"$",
				.var_address=&bbt_Text
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 704, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
		BBBYTE* bbt_s=0;
		BBINT bbt_out=0;
		BBBYTE* bbt_s2=0;
		struct BBDebugScope_3 __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				{
					BBDEBUGDECL_LOCAL,
					"s",
					"*b",
					.var_address=&bbt_s
				},
				{
					BBDEBUGDECL_LOCAL,
					"out",
					"i",
					.var_address=&bbt_out
				},
				{
					BBDEBUGDECL_LOCAL,
					"s2",
					"*b",
					.var_address=&bbt_s2
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 705, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(!(bbt_Text!= &bbEmptyString)){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 706, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bbt_Text=&bbEmptyString;
			bbOnDebugLeaveScope();
		}
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 709, 0};
		bbOnDebugEnterStm(&__stmt_1);
		bbt_s=bbStringToCString(bbt_Text);
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 710, 0};
		bbOnDebugEnterStm(&__stmt_2);
		bbt_out=0;
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 712, 0};
		bbOnDebugEnterStm(&__stmt_3);
		bbt_s2=curl_easy_unescape(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_s,(bbt_Text->length),(&bbt_out));
		struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 715, 0};
		bbOnDebugEnterStm(&__stmt_4);
		bbMemFree((void*)bbt_s);
		struct BBDebugStm __stmt_5 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 717, 0};
		bbOnDebugEnterStm(&__stmt_5);
		if(bbt_s2){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 719, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bbt_Text=bbStringFromBytes(bbt_s2,bbt_out);
			struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 722, 0};
			bbOnDebugEnterStm(&__stmt_1);
			curl_free(bbt_s2);
			struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 724, 0};
			bbOnDebugEnterStm(&__stmt_2);
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			return bbt_Text;
		}
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 728, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbOnDebugLeaveScope();
	return &bbEmptyString;
}
BBSTRING _bah_libcurl_curlmain_TCurlEasy_ToString(struct bah_libcurl_curlmain_TCurlEasy_obj* o){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"ToString",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 735, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbOnDebugLeaveScope();
	return ((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_data ;
}
void _bah_libcurl_curlmain_TCurlEasy_processArray_iaS(struct bah_libcurl_curlmain_TCurlEasy_obj* o,BBINT bbt_option,BBARRAY bbt_array){
	((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"processArray",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlEasy",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"option",
				"i",
				.var_address=&bbt_option
			},
			{
				BBDEBUGDECL_LOCAL,
				"array",
				"[]$",
				.var_address=&bbt_array
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 744, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if((bbt_array!= &bbEmptyArray) && ((bbt_array->scales[0])>0)){
		BBBYTE* bbt_slist=0;
		struct BBDebugScope_1 __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				{
					BBDEBUGDECL_LOCAL,
					"slist",
					"*b",
					.var_address=&bbt_slist
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 746, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_slist=bmx_curl_slist_new();
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 748, 0};
		bbOnDebugEnterStm(&__stmt_1);
		{
			BBINT bbt_i=0;
			BBINT bbt_=(bbt_array->scales[0]);
			for(bbt_i;(bbt_i<bbt_);bbt_i=(bbt_i+1)){
				BBBYTE* bbt_txt=0;
				struct BBDebugScope_2 __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						{
							BBDEBUGDECL_LOCAL,
							"i",
							"i",
							.var_address=&bbt_i
						},
						{
							BBDEBUGDECL_LOCAL,
							"txt",
							"*b",
							.var_address=&bbt_txt
						},
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 750, 0};
				bbOnDebugEnterStm(&__stmt_0);
				bbt_txt=bbStringToCString(((BBSTRING*)BBARRAYDATAINDEX((bbt_array),(bbt_array)->dims,((BBUINT)bbt_i)))[((BBUINT)bbt_i)]);
				struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 752, 0};
				bbOnDebugEnterStm(&__stmt_1);
				bmx_curl_add_element(bbt_slist,bbt_txt);
				struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 754, 0};
				bbOnDebugEnterStm(&__stmt_2);
				bbMemFree((void*)bbt_txt);
				bbOnDebugLeaveScope();
			}
		}
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 758, 0};
		bbOnDebugEnterStm(&__stmt_2);
		bmx_curl_easy_setopt_slist(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ,bbt_option,bbt_slist);
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 760, 0};
		bbOnDebugEnterStm(&__stmt_3);
		((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists =bbArraySlice("*b",((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists ,0,((((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists ->scales[0])+1));
		struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 762, 0};
		bbOnDebugEnterStm(&__stmt_4);
		((BBBYTE**)BBARRAYDATAINDEX((((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists ),(((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists )->dims,((BBUINT)((((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists ->scales[0])-1))))[((BBUINT)((((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlhaslists_slists ->scales[0])-1))]=bbt_slist;
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
struct BBDebugScope_50 bah_libcurl_curlmain_TCurlEasy_scope ={
	BBDEBUGSCOPE_USERTYPE,
	"TCurlEasy",
	{
		{
			BBDEBUGDECL_FIELD,
			"easyHandlePtr",
			"*b",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_easyhandleptr)
		},
		{
			BBDEBUGDECL_FIELD,
			"stringMap",
			":TMap",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_stringmap)
		},
		{
			BBDEBUGDECL_FIELD,
			"data",
			"$",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_data)
		},
		{
			BBDEBUGDECL_FIELD,
			"dbData",
			":Object",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_dbdata)
		},
		{
			BBDEBUGDECL_FIELD,
			"dbFunction",
			"(:Object,i,$)i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_dbfunction)
		},
		{
			BBDEBUGDECL_FIELD,
			"wrData",
			":Object",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_wrdata)
		},
		{
			BBDEBUGDECL_FIELD,
			"wrFunction",
			"(*b,i,:Object)i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_wrfunction)
		},
		{
			BBDEBUGDECL_FIELD,
			"rdData",
			":Object",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_rddata)
		},
		{
			BBDEBUGDECL_FIELD,
			"rdFunction",
			"(*b,i,:Object)i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_rdfunction)
		},
		{
			BBDEBUGDECL_FIELD,
			"hrData",
			":Object",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_hrdata)
		},
		{
			BBDEBUGDECL_FIELD,
			"hrFunction",
			"(*b,i,:Object)i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_hrfunction)
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"New",
			"()",
			&_bah_libcurl_curlmain_TCurlEasy_New
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"ToString",
			"()$",
			&_bah_libcurl_curlmain_TCurlEasy_ToString
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"Create",
			"():TCurlEasy",
			&bah_libcurl_curlmain_TCurlEasy_Create_TTCurlEasy
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setOpt",
			"(i,*b)",
			&_bah_libcurl_curlmain_TCurlEasy_setOpt_ipb
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setPrivate",
			"(:Object)",
			&_bah_libcurl_curlmain_TCurlEasy_setPrivate_TObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setOptInt",
			"(i,i)",
			&_bah_libcurl_curlmain_TCurlEasy_setOptInt_ii
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setOptLong",
			"(i,l)",
			&_bah_libcurl_curlmain_TCurlEasy_setOptLong_il
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setOptBytePtr",
			"(i,*b)",
			&_bah_libcurl_curlmain_TCurlEasy_setOptBytePtr_ipb
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setOptString",
			"(i,$)",
			&_bah_libcurl_curlmain_TCurlEasy_setOptString_iS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"perform",
			"()i",
			&_bah_libcurl_curlmain_TCurlEasy_perform
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"cleanup",
			"()",
			&_bah_libcurl_curlmain_TCurlEasy_cleanup
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"reset",
			"()",
			&_bah_libcurl_curlmain_TCurlEasy_reset
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setProgressCallback",
			"((:Object,d,d,d,d)i,:Object)",
			&_bah_libcurl_curlmain_TCurlEasy_setProgressCallback_F_TObjectdddd_i_TObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setDebugCallback",
			"((:Object,i,$)i,:Object)",
			&_bah_libcurl_curlmain_TCurlEasy_setDebugCallback_F_TObjectiS_i_TObject
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"dbCallback",
			"(*b,i,*b,i,:Object)i",
			&bah_libcurl_curlmain_TCurlEasy_dbCallback_i_pbipbiTObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setWriteStream",
			"(:TStream)",
			&_bah_libcurl_curlmain_TCurlEasy_setWriteStream_TTStream
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"writeStreamCallback",
			"(*b,i,i,:Object)i",
			&bah_libcurl_curlmain_TCurlEasy_writeStreamCallback_i_pbiiTObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setWriteCallback",
			"((*b,i,:Object)i,:Object)",
			&_bah_libcurl_curlmain_TCurlEasy_setWriteCallback_F_pbiTObject_i_TObject
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"wrCallback",
			"(*b,i,i,:Object)i",
			&bah_libcurl_curlmain_TCurlEasy_wrCallback_i_pbiiTObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setWriteString",
			"()",
			&_bah_libcurl_curlmain_TCurlEasy_setWriteString
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"writeStringFunction",
			"(*b,i,:Object)i",
			&bah_libcurl_curlmain_TCurlEasy_writeStringFunction_i_pbiTObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setReadStream",
			"(:TStream)",
			&_bah_libcurl_curlmain_TCurlEasy_setReadStream_TTStream
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"readStreamCallback",
			"(*b,i,i,:Object)i",
			&bah_libcurl_curlmain_TCurlEasy_readStreamCallback_i_pbiiTObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setReadCallback",
			"((*b,i,:Object)i,:Object)",
			&_bah_libcurl_curlmain_TCurlEasy_setReadCallback_F_pbiTObject_i_TObject
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"rdCallback",
			"(*b,i,i,:Object)i",
			&bah_libcurl_curlmain_TCurlEasy_rdCallback_i_pbiiTObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"setHeaderCallback",
			"((*b,i,:Object)i,:Object)",
			&_bah_libcurl_curlmain_TCurlEasy_setHeaderCallback_F_pbiTObject_i_TObject
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"hrCallback",
			"(*b,i,i,:Object)i",
			&bah_libcurl_curlmain_TCurlEasy_hrCallback_i_pbiiTObject
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"httpPost",
			"(:TCurlFormData)",
			&_bah_libcurl_curlmain_TCurlEasy_httpPost_TTCurlFormData
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"httpHeader",
			"([]$)",
			&_bah_libcurl_curlmain_TCurlEasy_httpHeader_aS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"http200Aliases",
			"([]$)",
			&_bah_libcurl_curlmain_TCurlEasy_http200Aliases_aS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"preQuote",
			"([]$)",
			&_bah_libcurl_curlmain_TCurlEasy_preQuote_aS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"quote",
			"([]$)",
			&_bah_libcurl_curlmain_TCurlEasy_quote_aS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"postQuote",
			"([]$)",
			&_bah_libcurl_curlmain_TCurlEasy_postQuote_aS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"telnetOptions",
			"([]$)",
			&_bah_libcurl_curlmain_TCurlEasy_telnetOptions_aS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"getInfo",
			"():TCurlInfo",
			&_bah_libcurl_curlmain_TCurlEasy_getInfo
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"freeLists",
			"()",
			&_bah_libcurl_curlmain_TCurlEasy_freeLists
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"escape",
			"($)$",
			&_bah_libcurl_curlmain_TCurlEasy_escape_S
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"unEscape",
			"($)$",
			&_bah_libcurl_curlmain_TCurlEasy_unEscape_S
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"processArray",
			"(i,[]$)",
			&_bah_libcurl_curlmain_TCurlEasy_processArray_iaS
		},
		BBDEBUGDECL_END
	}
};
struct BBClass_bah_libcurl_curlmain_TCurlEasy bah_libcurl_curlmain_TCurlEasy={
	&bah_libcurl_curlmain_TCurlHasLists,
	bbObjectFree,
	&bah_libcurl_curlmain_TCurlEasy_scope,
	sizeof(struct bah_libcurl_curlmain_TCurlEasy_obj),
	_bah_libcurl_curlmain_TCurlEasy_New,
	_bah_libcurl_curlmain_TCurlEasy_Delete,
	_bah_libcurl_curlmain_TCurlEasy_ToString,
	bbObjectCompare,
	bbObjectSendMessage,
	0,
	0,
	offsetof(struct bah_libcurl_curlmain_TCurlEasy_obj,_bah_libcurl_curlmain_tcurleasy_hrfunction) - sizeof(void*) + sizeof(BBINT(* )(BBBYTE*,BBINT,BBOBJECT))
	,_bah_libcurl_curlmain_TCurlEasy_freeLists
	,bah_libcurl_curlmain_TCurlEasy_Create_TTCurlEasy
	,_bah_libcurl_curlmain_TCurlEasy_setOpt_ipb
	,_bah_libcurl_curlmain_TCurlEasy_setPrivate_TObject
	,_bah_libcurl_curlmain_TCurlEasy_setOptInt_ii
	,_bah_libcurl_curlmain_TCurlEasy_setOptLong_il
	,_bah_libcurl_curlmain_TCurlEasy_setOptBytePtr_ipb
	,_bah_libcurl_curlmain_TCurlEasy_setOptString_iS
	,_bah_libcurl_curlmain_TCurlEasy_perform
	,_bah_libcurl_curlmain_TCurlEasy_cleanup
	,_bah_libcurl_curlmain_TCurlEasy_reset
	,_bah_libcurl_curlmain_TCurlEasy_setProgressCallback_F_TObjectdddd_i_TObject
	,_bah_libcurl_curlmain_TCurlEasy_setDebugCallback_F_TObjectiS_i_TObject
	,bah_libcurl_curlmain_TCurlEasy_dbCallback_i_pbipbiTObject
	,_bah_libcurl_curlmain_TCurlEasy_setWriteStream_TTStream
	,bah_libcurl_curlmain_TCurlEasy_writeStreamCallback_i_pbiiTObject
	,_bah_libcurl_curlmain_TCurlEasy_setWriteCallback_F_pbiTObject_i_TObject
	,bah_libcurl_curlmain_TCurlEasy_wrCallback_i_pbiiTObject
	,_bah_libcurl_curlmain_TCurlEasy_setWriteString
	,bah_libcurl_curlmain_TCurlEasy_writeStringFunction_i_pbiTObject
	,_bah_libcurl_curlmain_TCurlEasy_setReadStream_TTStream
	,bah_libcurl_curlmain_TCurlEasy_readStreamCallback_i_pbiiTObject
	,_bah_libcurl_curlmain_TCurlEasy_setReadCallback_F_pbiTObject_i_TObject
	,bah_libcurl_curlmain_TCurlEasy_rdCallback_i_pbiiTObject
	,_bah_libcurl_curlmain_TCurlEasy_setHeaderCallback_F_pbiTObject_i_TObject
	,bah_libcurl_curlmain_TCurlEasy_hrCallback_i_pbiiTObject
	,_bah_libcurl_curlmain_TCurlEasy_httpPost_TTCurlFormData
	,_bah_libcurl_curlmain_TCurlEasy_httpHeader_aS
	,_bah_libcurl_curlmain_TCurlEasy_http200Aliases_aS
	,_bah_libcurl_curlmain_TCurlEasy_preQuote_aS
	,_bah_libcurl_curlmain_TCurlEasy_quote_aS
	,_bah_libcurl_curlmain_TCurlEasy_postQuote_aS
	,_bah_libcurl_curlmain_TCurlEasy_telnetOptions_aS
	,_bah_libcurl_curlmain_TCurlEasy_getInfo
	,_bah_libcurl_curlmain_TCurlEasy_escape_S
	,_bah_libcurl_curlmain_TCurlEasy_unEscape_S
	,_bah_libcurl_curlmain_TCurlEasy_processArray_iaS
};

void _bah_libcurl_curlmain_TCurlInt_New(struct bah_libcurl_curlmain_TCurlInt_obj* o) {
	bbObjectCtor(o);
	o->clas = (BBClass*)&bah_libcurl_curlmain_TCurlInt;
	((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlint_opt = 0;
	((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlint_s = 0;
}
struct bah_libcurl_curlmain_TCurlInt_obj* bah_libcurl_curlmain_TCurlInt_set_TTCurlInt_ipb(BBINT bbt_opt,BBBYTE* bbt_s){
	struct bah_libcurl_curlmain_TCurlInt_obj* volatile bbt_this=&bbNullObject;
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"set",
		{
			{
				BBDEBUGDECL_LOCAL,
				"opt",
				"i",
				.var_address=&bbt_opt
			},
			{
				BBDEBUGDECL_LOCAL,
				"s",
				"*b",
				.var_address=&bbt_s
			},
			{
				BBDEBUGDECL_LOCAL,
				"this",
				":TCurlInt",
				.var_address=&bbt_this
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 774, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_this=bbObjectAtomicNew(&bah_libcurl_curlmain_TCurlInt);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 775, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_this))->_bah_libcurl_curlmain_tcurlint_opt =bbt_opt;
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 776, 0};
	bbOnDebugEnterStm(&__stmt_2);
	((struct bah_libcurl_curlmain_TCurlInt_obj*)bbNullObjectTest(bbt_this))->_bah_libcurl_curlmain_tcurlint_s =bbt_s;
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 777, 0};
	bbOnDebugEnterStm(&__stmt_3);
	bbOnDebugLeaveScope();
	return bbt_this;
}
struct BBDebugScope_4 bah_libcurl_curlmain_TCurlInt_scope ={
	BBDEBUGSCOPE_USERTYPE,
	"TCurlInt",
	{
		{
			BBDEBUGDECL_FIELD,
			"opt",
			"i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlInt_obj,_bah_libcurl_curlmain_tcurlint_opt)
		},
		{
			BBDEBUGDECL_FIELD,
			"s",
			"*b",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlInt_obj,_bah_libcurl_curlmain_tcurlint_s)
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"New",
			"()",
			&_bah_libcurl_curlmain_TCurlInt_New
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"set",
			"(i,*b):TCurlInt",
			&bah_libcurl_curlmain_TCurlInt_set_TTCurlInt_ipb
		},
		BBDEBUGDECL_END
	}
};
struct BBClass_bah_libcurl_curlmain_TCurlInt bah_libcurl_curlmain_TCurlInt={
	&bbObjectClass,
	bbObjectFree,
	&bah_libcurl_curlmain_TCurlInt_scope,
	sizeof(struct bah_libcurl_curlmain_TCurlInt_obj),
	_bah_libcurl_curlmain_TCurlInt_New,
	bbObjectDtor,
	bbObjectToString,
	bbObjectCompare,
	bbObjectSendMessage,
	0,
	0,
	offsetof(struct bah_libcurl_curlmain_TCurlInt_obj,_bah_libcurl_curlmain_tcurlint_s) - sizeof(void*) + sizeof(BBBYTE*)
	,bah_libcurl_curlmain_TCurlInt_set_TTCurlInt_ipb
};

void _bah_libcurl_curlmain_TCurlFormData_New(struct bah_libcurl_curlmain_TCurlFormData_obj* o) {
	_bah_libcurl_curlmain_TCurlHasLists_New(o);
	o->clas = (BBClass*)&bah_libcurl_curlmain_TCurlFormData;
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr = 0;
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_count = 0;
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs = bbArrayNew1D("*b", 0);
}
void _bah_libcurl_curlmain_TCurlFormData_Delete(struct bah_libcurl_curlmain_TCurlFormData_obj* o) {
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"Delete",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlFormData",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 919, 0};
	bbOnDebugEnterStm(&__stmt_0);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_free(o);
	bbOnDebugLeaveScope();
	bbObjectDtor(o);
}
struct bah_libcurl_curlmain_TCurlFormData_obj* bah_libcurl_curlmain_TCurlFormData_Create_TTCurlFormData(){
	struct bah_libcurl_curlmain_TCurlFormData_obj* volatile bbt_this=&bbNullObject;
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"Create",
		{
			{
				BBDEBUGDECL_LOCAL,
				"this",
				":TCurlFormData",
				.var_address=&bbt_this
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 796, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_this=bbObjectNew(&bah_libcurl_curlmain_TCurlFormData);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 798, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(bbt_this))->_bah_libcurl_curlmain_tcurlformdata_httppostptr =bmx_curl_new_httppostPtr();
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 800, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_this;
}
void _bah_libcurl_curlmain_TCurlFormData_addContent_SSSaS(struct bah_libcurl_curlmain_TCurlFormData_obj* o,BBSTRING bbt_name,BBSTRING bbt_contents,BBSTRING bbt_contentType,BBARRAY bbt_headers){
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	BBBYTE* bbt_n=0;
	BBBYTE* bbt_c=0;
	BBBYTE* bbt_t=0;
	struct BBDebugScope_8 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"addContent",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlFormData",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"name",
				"$",
				.var_address=&bbt_name
			},
			{
				BBDEBUGDECL_LOCAL,
				"contents",
				"$",
				.var_address=&bbt_contents
			},
			{
				BBDEBUGDECL_LOCAL,
				"contentType",
				"$",
				.var_address=&bbt_contentType
			},
			{
				BBDEBUGDECL_LOCAL,
				"headers",
				"[]$",
				.var_address=&bbt_headers
			},
			{
				BBDEBUGDECL_LOCAL,
				"n",
				"*b",
				.var_address=&bbt_n
			},
			{
				BBDEBUGDECL_LOCAL,
				"c",
				"*b",
				.var_address=&bbt_c
			},
			{
				BBDEBUGDECL_LOCAL,
				"t",
				"*b",
				.var_address=&bbt_t
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 807, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_n=bbStringToCString(bbt_name);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 808, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbt_c=bbStringToCString(bbt_contents);
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 809, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbt_t=0;
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 811, 0};
	bbOnDebugEnterStm(&__stmt_3);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_n);
	struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 812, 0};
	bbOnDebugEnterStm(&__stmt_4);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_c);
	struct BBDebugStm __stmt_5 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 814, 0};
	bbOnDebugEnterStm(&__stmt_5);
	if(bbt_contentType!= &bbEmptyString){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 815, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_t=bbStringToCString(bbt_contentType);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 816, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_t);
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 818, 0};
		bbOnDebugEnterStm(&__stmt_2);
		bmx_curl_formadd_name_content_type(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr ,bbt_n,bbt_c,bbt_t);
		bbOnDebugLeaveScope();
	}else{
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 820, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_formadd_name_content(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr ,bbt_n,bbt_c);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlFormData_addFile_SSSaS(struct bah_libcurl_curlmain_TCurlFormData_obj* o,BBSTRING bbt_name,BBSTRING bbt_file,BBSTRING bbt_contentType,BBARRAY bbt_headers){
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	BBBYTE* bbt_n=0;
	BBBYTE* bbt_f=0;
	BBBYTE* bbt_t=0;
	struct BBDebugScope_8 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"addFile",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlFormData",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"name",
				"$",
				.var_address=&bbt_name
			},
			{
				BBDEBUGDECL_LOCAL,
				"file",
				"$",
				.var_address=&bbt_file
			},
			{
				BBDEBUGDECL_LOCAL,
				"contentType",
				"$",
				.var_address=&bbt_contentType
			},
			{
				BBDEBUGDECL_LOCAL,
				"headers",
				"[]$",
				.var_address=&bbt_headers
			},
			{
				BBDEBUGDECL_LOCAL,
				"n",
				"*b",
				.var_address=&bbt_n
			},
			{
				BBDEBUGDECL_LOCAL,
				"f",
				"*b",
				.var_address=&bbt_f
			},
			{
				BBDEBUGDECL_LOCAL,
				"t",
				"*b",
				.var_address=&bbt_t
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 829, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_n=bbStringToCString(bbt_name);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 830, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbt_f=bbStringToCString(bbt_file);
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 831, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbt_t=0;
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 833, 0};
	bbOnDebugEnterStm(&__stmt_3);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_n);
	struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 834, 0};
	bbOnDebugEnterStm(&__stmt_4);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_f);
	struct BBDebugStm __stmt_5 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 836, 0};
	bbOnDebugEnterStm(&__stmt_5);
	if(bbt_contentType!= &bbEmptyString){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 837, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_t=bbStringToCString(bbt_contentType);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 838, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_t);
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 840, 0};
		bbOnDebugEnterStm(&__stmt_2);
		bmx_curl_formadd_name_file_type(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr ,bbt_n,bbt_f,bbt_t,1);
		bbOnDebugLeaveScope();
	}else{
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 842, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_formadd_name_file(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr ,bbt_n,bbt_f,1);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlFormData_addFileContent_SSSaS(struct bah_libcurl_curlmain_TCurlFormData_obj* o,BBSTRING bbt_name,BBSTRING bbt_file,BBSTRING bbt_contentType,BBARRAY bbt_headers){
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	BBBYTE* bbt_n=0;
	BBBYTE* bbt_f=0;
	BBBYTE* bbt_t=0;
	struct BBDebugScope_8 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"addFileContent",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlFormData",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"name",
				"$",
				.var_address=&bbt_name
			},
			{
				BBDEBUGDECL_LOCAL,
				"file",
				"$",
				.var_address=&bbt_file
			},
			{
				BBDEBUGDECL_LOCAL,
				"contentType",
				"$",
				.var_address=&bbt_contentType
			},
			{
				BBDEBUGDECL_LOCAL,
				"headers",
				"[]$",
				.var_address=&bbt_headers
			},
			{
				BBDEBUGDECL_LOCAL,
				"n",
				"*b",
				.var_address=&bbt_n
			},
			{
				BBDEBUGDECL_LOCAL,
				"f",
				"*b",
				.var_address=&bbt_f
			},
			{
				BBDEBUGDECL_LOCAL,
				"t",
				"*b",
				.var_address=&bbt_t
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 851, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_n=bbStringToCString(bbt_name);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 852, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbt_f=bbStringToCString(bbt_file);
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 853, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbt_t=0;
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 855, 0};
	bbOnDebugEnterStm(&__stmt_3);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_n);
	struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 856, 0};
	bbOnDebugEnterStm(&__stmt_4);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_f);
	struct BBDebugStm __stmt_5 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 858, 0};
	bbOnDebugEnterStm(&__stmt_5);
	if(bbt_contentType!= &bbEmptyString){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 859, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_t=bbStringToCString(bbt_contentType);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 860, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_t);
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 862, 0};
		bbOnDebugEnterStm(&__stmt_2);
		bmx_curl_formadd_name_file_type(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr ,bbt_n,bbt_f,bbt_t,2);
		bbOnDebugLeaveScope();
	}else{
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 864, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_formadd_name_file(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr ,bbt_n,bbt_f,2);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlFormData_addBuffer_SSpbiaS(struct bah_libcurl_curlmain_TCurlFormData_obj* o,BBSTRING bbt_name,BBSTRING bbt_bufName,BBBYTE* bbt_buffer,BBINT bbt_length,BBARRAY bbt_headers){
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	BBBYTE* bbt_n=0;
	BBBYTE* bbt_b=0;
	struct BBDebugScope_8 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"addBuffer",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlFormData",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"name",
				"$",
				.var_address=&bbt_name
			},
			{
				BBDEBUGDECL_LOCAL,
				"bufName",
				"$",
				.var_address=&bbt_bufName
			},
			{
				BBDEBUGDECL_LOCAL,
				"buffer",
				"*b",
				.var_address=&bbt_buffer
			},
			{
				BBDEBUGDECL_LOCAL,
				"length",
				"i",
				.var_address=&bbt_length
			},
			{
				BBDEBUGDECL_LOCAL,
				"headers",
				"[]$",
				.var_address=&bbt_headers
			},
			{
				BBDEBUGDECL_LOCAL,
				"n",
				"*b",
				.var_address=&bbt_n
			},
			{
				BBDEBUGDECL_LOCAL,
				"b",
				"*b",
				.var_address=&bbt_b
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 873, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_n=bbStringToCString(bbt_name);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 874, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbt_b=bbStringToCString(bbt_bufName);
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 876, 0};
	bbOnDebugEnterStm(&__stmt_2);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_n);
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 877, 0};
	bbOnDebugEnterStm(&__stmt_3);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)o)->clas->m_addPtr_pb(o,bbt_b);
	struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 879, 0};
	bbOnDebugEnterStm(&__stmt_4);
	bmx_curl_formadd_name_buffer(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr ,bbt_n,bbt_b,bbt_buffer,bbt_length);
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlFormData_addPtr_pb(struct bah_libcurl_curlmain_TCurlFormData_obj* o,BBBYTE* bbt_newPtr){
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"addPtr",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlFormData",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"newPtr",
				"*b",
				.var_address=&bbt_newPtr
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 886, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_count ==(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs ->scales[0])){
		BBARRAY bbt_tmpPtrs=&bbEmptyArray;
		struct BBDebugScope_1 __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				{
					BBDEBUGDECL_LOCAL,
					"tmpPtrs",
					"[]*b",
					.var_address=&bbt_tmpPtrs
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 888, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_tmpPtrs=bbArrayNew1D("*b", ((((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs ->scales[0])+5));
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 890, 0};
		bbOnDebugEnterStm(&__stmt_1);
		{
			BBINT bbt_i=0;
			BBINT bbt_=((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_count ;
			for(bbt_i;(bbt_i<bbt_);bbt_i=(bbt_i+1)){
				struct BBDebugScope_1 __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						{
							BBDEBUGDECL_LOCAL,
							"i",
							"i",
							.var_address=&bbt_i
						},
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 891, 0};
				bbOnDebugEnterStm(&__stmt_0);
				((BBBYTE**)BBARRAYDATAINDEX((bbt_tmpPtrs),(bbt_tmpPtrs)->dims,((BBUINT)bbt_i)))[((BBUINT)bbt_i)]=((BBBYTE**)BBARRAYDATAINDEX((((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs ),(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs )->dims,((BBUINT)bbt_i)))[((BBUINT)bbt_i)];
				bbOnDebugLeaveScope();
			}
		}
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 894, 0};
		bbOnDebugEnterStm(&__stmt_2);
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs =bbt_tmpPtrs;
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 897, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((BBBYTE**)BBARRAYDATAINDEX((((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs ),(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs )->dims,((BBUINT)((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_count )))[((BBUINT)((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_count )]=bbt_newPtr;
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 899, 0};
	bbOnDebugEnterStm(&__stmt_2);
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_count +=1;
	bbOnDebugLeaveScope();
}
void _bah_libcurl_curlmain_TCurlFormData_free(struct bah_libcurl_curlmain_TCurlFormData_obj* o){
	((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"free",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlFormData",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 903, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 904, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_httppostPtr_delete(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr );
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 905, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_httppostptr =0;
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 908, 0};
	bbOnDebugEnterStm(&__stmt_1);
	if((((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs != &bbEmptyArray) && (((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_count >0)){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 909, 0};
		bbOnDebugEnterStm(&__stmt_0);
		{
			BBINT bbt_i=0;
			BBINT bbt_=((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_count ;
			for(bbt_i;(bbt_i<bbt_);bbt_i=(bbt_i+1)){
				struct BBDebugScope_1 __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						{
							BBDEBUGDECL_LOCAL,
							"i",
							"i",
							.var_address=&bbt_i
						},
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 910, 0};
				bbOnDebugEnterStm(&__stmt_0);
				bbMemFree((void*)((BBBYTE**)BBARRAYDATAINDEX((((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs ),(((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs )->dims,((BBUINT)bbt_i)))[((BBUINT)bbt_i)]);
				bbOnDebugLeaveScope();
			}
		}
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 912, 0};
		bbOnDebugEnterStm(&__stmt_1);
		((struct bah_libcurl_curlmain_TCurlFormData_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlformdata_ptrs =&bbEmptyArray;
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 915, 0};
	bbOnDebugEnterStm(&__stmt_2);
	((struct bah_libcurl_curlmain_TCurlHasLists_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlHasLists_obj*)o)->clas->m_freeLists(o);
	bbOnDebugLeaveScope();
}
struct BBDebugScope_11 bah_libcurl_curlmain_TCurlFormData_scope ={
	BBDEBUGSCOPE_USERTYPE,
	"TCurlFormData",
	{
		{
			BBDEBUGDECL_FIELD,
			"httppostPtr",
			"*b",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlFormData_obj,_bah_libcurl_curlmain_tcurlformdata_httppostptr)
		},
		{
			BBDEBUGDECL_FIELD,
			"count",
			"i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlFormData_obj,_bah_libcurl_curlmain_tcurlformdata_count)
		},
		{
			BBDEBUGDECL_FIELD,
			"ptrs",
			"[]*b",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlFormData_obj,_bah_libcurl_curlmain_tcurlformdata_ptrs)
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"New",
			"()",
			&_bah_libcurl_curlmain_TCurlFormData_New
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"Create",
			"():TCurlFormData",
			&bah_libcurl_curlmain_TCurlFormData_Create_TTCurlFormData
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"addContent",
			"($,$,$,[]$)",
			&_bah_libcurl_curlmain_TCurlFormData_addContent_SSSaS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"addFile",
			"($,$,$,[]$)",
			&_bah_libcurl_curlmain_TCurlFormData_addFile_SSSaS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"addFileContent",
			"($,$,$,[]$)",
			&_bah_libcurl_curlmain_TCurlFormData_addFileContent_SSSaS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"addBuffer",
			"($,$,*b,i,[]$)",
			&_bah_libcurl_curlmain_TCurlFormData_addBuffer_SSpbiaS
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"addPtr",
			"(*b)",
			&_bah_libcurl_curlmain_TCurlFormData_addPtr_pb
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"free",
			"()",
			&_bah_libcurl_curlmain_TCurlFormData_free
		},
		BBDEBUGDECL_END
	}
};
struct BBClass_bah_libcurl_curlmain_TCurlFormData bah_libcurl_curlmain_TCurlFormData={
	&bah_libcurl_curlmain_TCurlHasLists,
	bbObjectFree,
	&bah_libcurl_curlmain_TCurlFormData_scope,
	sizeof(struct bah_libcurl_curlmain_TCurlFormData_obj),
	_bah_libcurl_curlmain_TCurlFormData_New,
	_bah_libcurl_curlmain_TCurlFormData_Delete,
	bbObjectToString,
	bbObjectCompare,
	bbObjectSendMessage,
	0,
	0,
	offsetof(struct bah_libcurl_curlmain_TCurlFormData_obj,_bah_libcurl_curlmain_tcurlformdata_ptrs) - sizeof(void*) + sizeof(BBARRAY)
	,_bah_libcurl_curlmain_TCurlHasLists_freeLists
	,bah_libcurl_curlmain_TCurlFormData_Create_TTCurlFormData
	,_bah_libcurl_curlmain_TCurlFormData_addContent_SSSaS
	,_bah_libcurl_curlmain_TCurlFormData_addFile_SSSaS
	,_bah_libcurl_curlmain_TCurlFormData_addFileContent_SSSaS
	,_bah_libcurl_curlmain_TCurlFormData_addBuffer_SSpbiaS
	,_bah_libcurl_curlmain_TCurlFormData_addPtr_pb
	,_bah_libcurl_curlmain_TCurlFormData_free
};

void _bah_libcurl_curlmain_TCurlInfo_New(struct bah_libcurl_curlmain_TCurlInfo_obj* o) {
	bbObjectCtor(o);
	o->clas = (BBClass*)&bah_libcurl_curlmain_TCurlInfo;
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr = 0;
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error = 0;
}
struct bah_libcurl_curlmain_TCurlInfo_obj* bah_libcurl_curlmain_TCurlInfo__create_TTCurlInfo_pb(BBBYTE* bbt_easyHandlePtr){
	struct bah_libcurl_curlmain_TCurlInfo_obj* volatile bbt_this=&bbNullObject;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"_create",
		{
			{
				BBDEBUGDECL_LOCAL,
				"easyHandlePtr",
				"*b",
				.var_address=&bbt_easyHandlePtr
			},
			{
				BBDEBUGDECL_LOCAL,
				"this",
				":TCurlInfo",
				.var_address=&bbt_this
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 936, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_this=bbObjectAtomicNew(&bah_libcurl_curlmain_TCurlInfo);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 938, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(bbt_this))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr =bbt_easyHandlePtr;
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 940, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_this;
}
BBSTRING _bah_libcurl_curlmain_TCurlInfo_effectiveURL(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBBYTE* bbt_s=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"effectiveURL",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"s",
				"*b",
				.var_address=&bbt_s
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 947, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_s=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 949, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_string(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,1048577,(&bbt_s));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 951, 0};
	bbOnDebugEnterStm(&__stmt_2);
	if(!(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error !=0)){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 952, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return bbStringFromCString(bbt_s);
	}
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 955, 0};
	bbOnDebugEnterStm(&__stmt_3);
	bbOnDebugLeaveScope();
	return &bbEmptyString;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_responseCode(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"responseCode",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 964, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 966, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097154,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 968, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_httpConnectCode(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"httpConnectCode",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 975, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 977, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097166,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 979, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_FileTime(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"FileTime",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 990, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 992, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097175,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 994, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_totalTime(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"totalTime",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1001, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1003, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145731,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1005, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_namelookupTime(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"namelookupTime",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1012, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1014, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145732,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1016, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_connectTime(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"connectTime",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1023, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1025, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145733,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1027, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_preTransferTime(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"preTransferTime",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1036, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1038, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145734,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1040, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_startTransferTime(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"startTransferTime",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1048, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1050, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145745,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1052, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_redirectTime(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"redirectTime",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1060, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1062, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145747,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1064, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_redirectCount(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"redirectCount",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1071, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1073, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097172,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1075, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_sizeUpload(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"sizeUpload",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1082, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1084, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145735,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1086, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_sizeDownload(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"sizeDownload",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1094, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1096, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145736,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1098, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_speedDownload(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"speedDownload",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1106, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1108, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145737,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1110, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_speedUpload(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"speedUpload",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1118, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1120, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145738,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1122, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_headerSize(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"headerSize",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1130, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1132, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097163,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1134, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_requestSize(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"requestSize",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1143, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1145, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097164,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1147, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_sslVerifyResult(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"sslVerifyResult",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1154, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1156, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097165,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1158, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBARRAY _bah_libcurl_curlmain_TCurlInfo_sslEngines(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"sslEngines",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1168, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbOnDebugLeaveScope();
	return bah_libcurl_common_curlProcessSlist(bmx_curl_easy_getinfo_slist(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,4194331,(&((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error )));
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_contentLengthDownload(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"contentLengthDownload",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1177, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1179, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145743,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1181, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBDOUBLE _bah_libcurl_curlmain_TCurlInfo_contentLengthUpload(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBDOUBLE bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"contentLengthUpload",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"d",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1188, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=.0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1190, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_double(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,3145744,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1192, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBSTRING _bah_libcurl_curlmain_TCurlInfo_contentType(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBBYTE* bbt_s=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"contentType",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"s",
				"*b",
				.var_address=&bbt_s
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1201, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_s=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1203, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_string(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,1048594,(&bbt_s));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1205, 0};
	bbOnDebugEnterStm(&__stmt_2);
	if(!(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error !=0)){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1206, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(bbt_s){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1207, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			return bbStringFromCString(bbt_s);
		}
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1211, 0};
	bbOnDebugEnterStm(&__stmt_3);
	bbOnDebugLeaveScope();
	return &bbEmptyString;
}
BBOBJECT _bah_libcurl_curlmain_TCurlInfo_privateData(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"privateData",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1218, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbOnDebugLeaveScope();
	return bmx_curl_easy_getinfo_obj(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,1048597,(&((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error ));
}
BBINT _bah_libcurl_curlmain_TCurlInfo_httpAuthAvail(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"httpAuthAvail",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1226, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1228, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097175,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1230, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_proxyAuthAvail(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"proxyAuthAvail",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1238, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1240, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097176,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1242, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_osErrno(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"osErrno",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1249, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1251, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097177,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1253, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_numConnects(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"numConnects",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1262, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1264, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097178,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1266, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBARRAY _bah_libcurl_curlmain_TCurlInfo_cookieList(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"cookieList",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1276, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbOnDebugLeaveScope();
	return bah_libcurl_common_curlProcessSlist(bmx_curl_easy_getinfo_slist(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,4194332,(&((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error )));
}
BBINT _bah_libcurl_curlmain_TCurlInfo_lastSocket(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBINT bbt_value=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"lastSocket",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"value",
				"i",
				.var_address=&bbt_value
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1287, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_value=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1289, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_long(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,2097181,(&bbt_value));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1291, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_value;
}
BBSTRING _bah_libcurl_curlmain_TCurlInfo_ftpEntryPath(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	BBBYTE* bbt_s=0;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"ftpEntryPath",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"s",
				"*b",
				.var_address=&bbt_s
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1300, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_s=0;
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1302, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error =bmx_curl_easy_getinfo_string(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_easyhandleptr ,1048606,(&bbt_s));
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1304, 0};
	bbOnDebugEnterStm(&__stmt_2);
	if(!(((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error !=0)){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1305, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(bbt_s){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1306, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			return bbStringFromCString(bbt_s);
		}
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1310, 0};
	bbOnDebugEnterStm(&__stmt_3);
	bbOnDebugLeaveScope();
	return &bbEmptyString;
}
BBINT _bah_libcurl_curlmain_TCurlInfo_errorCode(struct bah_libcurl_curlmain_TCurlInfo_obj* o){
	((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"errorCode",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlInfo",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1317, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbOnDebugLeaveScope();
	return ((struct bah_libcurl_curlmain_TCurlInfo_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlinfo_error ;
}
struct BBDebugScope_35 bah_libcurl_curlmain_TCurlInfo_scope ={
	BBDEBUGSCOPE_USERTYPE,
	"TCurlInfo",
	{
		{
			BBDEBUGDECL_FIELD,
			"easyHandlePtr",
			"*b",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlInfo_obj,_bah_libcurl_curlmain_tcurlinfo_easyhandleptr)
		},
		{
			BBDEBUGDECL_FIELD,
			"error",
			"i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlInfo_obj,_bah_libcurl_curlmain_tcurlinfo_error)
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"New",
			"()",
			&_bah_libcurl_curlmain_TCurlInfo_New
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"_create",
			"(*b):TCurlInfo",
			&bah_libcurl_curlmain_TCurlInfo__create_TTCurlInfo_pb
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"effectiveURL",
			"()$",
			&_bah_libcurl_curlmain_TCurlInfo_effectiveURL
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"responseCode",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_responseCode
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"httpConnectCode",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_httpConnectCode
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"FileTime",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_FileTime
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"totalTime",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_totalTime
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"namelookupTime",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_namelookupTime
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"connectTime",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_connectTime
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"preTransferTime",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_preTransferTime
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"startTransferTime",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_startTransferTime
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"redirectTime",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_redirectTime
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"redirectCount",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_redirectCount
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"sizeUpload",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_sizeUpload
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"sizeDownload",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_sizeDownload
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"speedDownload",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_speedDownload
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"speedUpload",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_speedUpload
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"headerSize",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_headerSize
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"requestSize",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_requestSize
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"sslVerifyResult",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_sslVerifyResult
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"sslEngines",
			"()[]$",
			&_bah_libcurl_curlmain_TCurlInfo_sslEngines
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"contentLengthDownload",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_contentLengthDownload
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"contentLengthUpload",
			"()d",
			&_bah_libcurl_curlmain_TCurlInfo_contentLengthUpload
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"contentType",
			"()$",
			&_bah_libcurl_curlmain_TCurlInfo_contentType
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"privateData",
			"():Object",
			&_bah_libcurl_curlmain_TCurlInfo_privateData
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"httpAuthAvail",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_httpAuthAvail
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"proxyAuthAvail",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_proxyAuthAvail
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"osErrno",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_osErrno
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"numConnects",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_numConnects
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"cookieList",
			"()[]$",
			&_bah_libcurl_curlmain_TCurlInfo_cookieList
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"lastSocket",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_lastSocket
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"ftpEntryPath",
			"()$",
			&_bah_libcurl_curlmain_TCurlInfo_ftpEntryPath
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"errorCode",
			"()i",
			&_bah_libcurl_curlmain_TCurlInfo_errorCode
		},
		BBDEBUGDECL_END
	}
};
struct BBClass_bah_libcurl_curlmain_TCurlInfo bah_libcurl_curlmain_TCurlInfo={
	&bbObjectClass,
	bbObjectFree,
	&bah_libcurl_curlmain_TCurlInfo_scope,
	sizeof(struct bah_libcurl_curlmain_TCurlInfo_obj),
	_bah_libcurl_curlmain_TCurlInfo_New,
	bbObjectDtor,
	bbObjectToString,
	bbObjectCompare,
	bbObjectSendMessage,
	0,
	0,
	offsetof(struct bah_libcurl_curlmain_TCurlInfo_obj,_bah_libcurl_curlmain_tcurlinfo_error) - sizeof(void*) + sizeof(BBINT)
	,bah_libcurl_curlmain_TCurlInfo__create_TTCurlInfo_pb
	,_bah_libcurl_curlmain_TCurlInfo_effectiveURL
	,_bah_libcurl_curlmain_TCurlInfo_responseCode
	,_bah_libcurl_curlmain_TCurlInfo_httpConnectCode
	,_bah_libcurl_curlmain_TCurlInfo_FileTime
	,_bah_libcurl_curlmain_TCurlInfo_totalTime
	,_bah_libcurl_curlmain_TCurlInfo_namelookupTime
	,_bah_libcurl_curlmain_TCurlInfo_connectTime
	,_bah_libcurl_curlmain_TCurlInfo_preTransferTime
	,_bah_libcurl_curlmain_TCurlInfo_startTransferTime
	,_bah_libcurl_curlmain_TCurlInfo_redirectTime
	,_bah_libcurl_curlmain_TCurlInfo_redirectCount
	,_bah_libcurl_curlmain_TCurlInfo_sizeUpload
	,_bah_libcurl_curlmain_TCurlInfo_sizeDownload
	,_bah_libcurl_curlmain_TCurlInfo_speedDownload
	,_bah_libcurl_curlmain_TCurlInfo_speedUpload
	,_bah_libcurl_curlmain_TCurlInfo_headerSize
	,_bah_libcurl_curlmain_TCurlInfo_requestSize
	,_bah_libcurl_curlmain_TCurlInfo_sslVerifyResult
	,_bah_libcurl_curlmain_TCurlInfo_sslEngines
	,_bah_libcurl_curlmain_TCurlInfo_contentLengthDownload
	,_bah_libcurl_curlmain_TCurlInfo_contentLengthUpload
	,_bah_libcurl_curlmain_TCurlInfo_contentType
	,_bah_libcurl_curlmain_TCurlInfo_privateData
	,_bah_libcurl_curlmain_TCurlInfo_httpAuthAvail
	,_bah_libcurl_curlmain_TCurlInfo_proxyAuthAvail
	,_bah_libcurl_curlmain_TCurlInfo_osErrno
	,_bah_libcurl_curlmain_TCurlInfo_numConnects
	,_bah_libcurl_curlmain_TCurlInfo_cookieList
	,_bah_libcurl_curlmain_TCurlInfo_lastSocket
	,_bah_libcurl_curlmain_TCurlInfo_ftpEntryPath
	,_bah_libcurl_curlmain_TCurlInfo_errorCode
};

void _bah_libcurl_curlmain_TCurlMulti_New(struct bah_libcurl_curlmain_TCurlMulti_obj* o) {
	bbObjectCtor(o);
	o->clas = (BBClass*)&bah_libcurl_curlmain_TCurlMulti;
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr = 0;
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles = bbObjectNew(&brl_linkedlist_TList);
}
void _bah_libcurl_curlmain_TCurlMulti_Delete(struct bah_libcurl_curlmain_TCurlMulti_obj* o) {
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"Delete",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1601, 0};
	bbOnDebugEnterStm(&__stmt_0);
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)o)->clas->m_multiCleanup(o);
	bbOnDebugLeaveScope();
	bbObjectDtor(o);
}
struct bah_libcurl_curlmain_TCurlMulti_obj* bah_libcurl_curlmain_TCurlMulti_Create_TTCurlMulti(){
	struct bah_libcurl_curlmain_TCurlMulti_obj* volatile bbt_this=&bbNullObject;
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"Create",
		{
			{
				BBDEBUGDECL_LOCAL,
				"this",
				":TCurlMulti",
				.var_address=&bbt_this
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1408, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_this=bbObjectNew(&bah_libcurl_curlmain_TCurlMulti);
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1410, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(bbt_this))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr =curl_multi_init();
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1412, 0};
	bbOnDebugEnterStm(&__stmt_2);
	if(!(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(bbt_this))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr )){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1413, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return &bbNullObject;
	}
	struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1416, 0};
	bbOnDebugEnterStm(&__stmt_3);
	bbOnDebugLeaveScope();
	return bbt_this;
}
struct bah_libcurl_curlmain_TCurlEasy_obj* _bah_libcurl_curlmain_TCurlMulti_newEasy(struct bah_libcurl_curlmain_TCurlMulti_obj* o){
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	struct bah_libcurl_curlmain_TCurlEasy_obj* volatile bbt_easy=&bbNullObject;
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"newEasy",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"easy",
				":TCurlEasy",
				.var_address=&bbt_easy
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1424, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbt_easy=bah_libcurl_curlmain_TCurlEasy_Create_TTCurlEasy();
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1425, 0};
	bbOnDebugEnterStm(&__stmt_1);
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)o)->clas->m_multiAdd_TTCurlEasy(o,bbt_easy);
	struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1426, 0};
	bbOnDebugEnterStm(&__stmt_2);
	bbOnDebugLeaveScope();
	return bbt_easy;
}
BBINT _bah_libcurl_curlmain_TCurlMulti_multiAdd_TTCurlEasy(struct bah_libcurl_curlmain_TCurlMulti_obj* o,struct bah_libcurl_curlmain_TCurlEasy_obj* bbt_easy){
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"multiAdd",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"easy",
				":TCurlEasy",
				.var_address=&bbt_easy
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1438, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ) && (bbt_easy!= &bbNullObject)) && (((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_easy))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr )){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1439, 0};
		bbOnDebugEnterStm(&__stmt_0);
		(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles )->clas->m_AddLast_TObject(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles ,bbt_easy);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1440, 0};
		bbOnDebugEnterStm(&__stmt_1);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return curl_multi_add_handle(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ,((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_easy))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr );
	}
	bbOnDebugLeaveScope();
	return 0;
}
BBINT _bah_libcurl_curlmain_TCurlMulti_multiRemove_TTCurlEasy(struct bah_libcurl_curlmain_TCurlMulti_obj* o,struct bah_libcurl_curlmain_TCurlEasy_obj* bbt_easy){
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"multiRemove",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"easy",
				":TCurlEasy",
				.var_address=&bbt_easy
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1456, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ) && (bbt_easy!= &bbNullObject)) && (((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_easy))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr )){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1458, 0};
		bbOnDebugEnterStm(&__stmt_0);
		(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles )->clas->m_Remove_TObject(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles ,bbt_easy);
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1460, 0};
		bbOnDebugEnterStm(&__stmt_1);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return curl_multi_remove_handle(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ,((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_easy))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr );
	}
	bbOnDebugLeaveScope();
	return 0;
}
BBINT _bah_libcurl_curlmain_TCurlMulti_multiPerform_vi(struct bah_libcurl_curlmain_TCurlMulti_obj* o,BBINT* bbt_runningHandles){
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"multiPerform",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			{
				BBDEBUGDECL_VARPARAM,
				"runningHandles",
				"i",
				.var_address=&bbt_runningHandles
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1492, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1494, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return curl_multi_perform(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ,&(*bbt_runningHandles));
	}
	bbOnDebugLeaveScope();
	return 0;
}
BBINT _bah_libcurl_curlmain_TCurlMulti_multiSelect_d(struct bah_libcurl_curlmain_TCurlMulti_obj* o,BBDOUBLE bbt_timeout){
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"multiSelect",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"timeout",
				"d",
				.var_address=&bbt_timeout
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1503, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1505, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbOnDebugLeaveScope();
		bbOnDebugLeaveScope();
		return bmx_curl_multiselect(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ,bbt_timeout);
	}
	bbOnDebugLeaveScope();
	return 0;
}
void _bah_libcurl_curlmain_TCurlMulti_multiCleanup(struct bah_libcurl_curlmain_TCurlMulti_obj* o){
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"multiCleanup",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1524, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1525, 0};
		bbOnDebugEnterStm(&__stmt_0);
		if(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles != &bbNullObject){
			struct BBDebugScope __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1526, 0};
			bbOnDebugEnterStm(&__stmt_0);
			struct brl_linkedlist_TListEnum_obj* volatile bbt_=(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles )->clas->m_ObjectEnumerator(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles );
			while((bbt_)->clas->m_HasNext(bbt_)!=0){
				struct bah_libcurl_curlmain_TCurlEasy_obj* volatile bbt_easy=&bbNullObject;
				struct BBDebugScope_1 __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						{
							BBDEBUGDECL_LOCAL,
							"easy",
							":TCurlEasy",
							.var_address=&bbt_easy
						},
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				bbt_easy=((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast((bbt_)->clas->m_NextObject(bbt_),&bah_libcurl_curlmain_TCurlEasy));
				if(bbt_easy==&bbNullObject){
					bbOnDebugLeaveScope();
					continue;
				}
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1528, 0};
				bbOnDebugEnterStm(&__stmt_0);
				if(((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_easy))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
					struct BBDebugScope __scope = {
						BBDEBUGSCOPE_LOCALBLOCK,
						0,
						{
							BBDEBUGDECL_END 
						}
					};
					bbOnDebugEnterScope(&__scope);
					struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1529, 0};
					bbOnDebugEnterStm(&__stmt_0);
					curl_multi_remove_handle(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ,((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_easy))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr );
					bbOnDebugLeaveScope();
				}
				bbOnDebugLeaveScope();
			}
			bbOnDebugLeaveScope();
		}
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1535, 0};
		bbOnDebugEnterStm(&__stmt_1);
		(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles )->clas->m_Clear(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles );
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1537, 0};
		bbOnDebugEnterStm(&__stmt_2);
		curl_multi_cleanup(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr );
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1538, 0};
		bbOnDebugEnterStm(&__stmt_3);
		((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr =0;
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
struct bah_libcurl_curlmain_TCurlMultiMsg_obj* _bah_libcurl_curlmain_TCurlMulti_multiInfoRead_vi(struct bah_libcurl_curlmain_TCurlMulti_obj* o,BBINT* bbt_messagesInQueue){
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	struct BBDebugScope_2 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"multiInfoRead",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			{
				BBDEBUGDECL_VARPARAM,
				"messagesInQueue",
				"i",
				.var_address=&bbt_messagesInQueue
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1559, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ){
		BBBYTE* bbt_infoPtr=0;
		struct BBDebugScope_1 __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				{
					BBDEBUGDECL_LOCAL,
					"infoPtr",
					"*b",
					.var_address=&bbt_infoPtr
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1560, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_infoPtr=curl_multi_info_read(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ,&(*bbt_messagesInQueue));
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1562, 0};
		bbOnDebugEnterStm(&__stmt_1);
		if(bbt_infoPtr){
			struct bah_libcurl_curlmain_TCurlMultiMsg_obj* volatile bbt_info=&bbNullObject;
			BBBYTE* bbt_ePtr=0;
			struct BBDebugScope_2 __scope = {
				BBDEBUGSCOPE_LOCALBLOCK,
				0,
				{
					{
						BBDEBUGDECL_LOCAL,
						"info",
						":TCurlMultiMsg",
						.var_address=&bbt_info
					},
					{
						BBDEBUGDECL_LOCAL,
						"ePtr",
						"*b",
						.var_address=&bbt_ePtr
					},
					BBDEBUGDECL_END 
				}
			};
			bbOnDebugEnterScope(&__scope);
			struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1564, 0};
			bbOnDebugEnterStm(&__stmt_0);
			bbt_info=bbObjectNew(&bah_libcurl_curlmain_TCurlMultiMsg);
			struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1566, 0};
			bbOnDebugEnterStm(&__stmt_1);
			((struct bah_libcurl_curlmain_TCurlMultiMsg_obj*)bbNullObjectTest(bbt_info))->_bah_libcurl_curlmain_tcurlmultimsg_message =bmx_curl_CURLMsg_msg(bbt_infoPtr);
			struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1568, 0};
			bbOnDebugEnterStm(&__stmt_2);
			if(((struct bah_libcurl_curlmain_TCurlMultiMsg_obj*)bbNullObjectTest(bbt_info))->_bah_libcurl_curlmain_tcurlmultimsg_message ==1){
				struct BBDebugScope __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1569, 0};
				bbOnDebugEnterStm(&__stmt_0);
				((struct bah_libcurl_curlmain_TCurlMultiMsg_obj*)bbNullObjectTest(bbt_info))->_bah_libcurl_curlmain_tcurlmultimsg_result =bmx_curl_CURLMsg_result(bbt_infoPtr);
				bbOnDebugLeaveScope();
			}
			struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1572, 0};
			bbOnDebugEnterStm(&__stmt_3);
			bbt_ePtr=bmx_curl_CURLMsg_easy_handle(bbt_infoPtr);
			struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1574, 0};
			bbOnDebugEnterStm(&__stmt_4);
			struct brl_linkedlist_TListEnum_obj* volatile bbt_=(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles )->clas->m_ObjectEnumerator(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_easyhandles );
			while((bbt_)->clas->m_HasNext(bbt_)!=0){
				struct bah_libcurl_curlmain_TCurlEasy_obj* volatile bbt_e=&bbNullObject;
				struct BBDebugScope_1 __scope = {
					BBDEBUGSCOPE_LOCALBLOCK,
					0,
					{
						{
							BBDEBUGDECL_LOCAL,
							"e",
							":TCurlEasy",
							.var_address=&bbt_e
						},
						BBDEBUGDECL_END 
					}
				};
				bbOnDebugEnterScope(&__scope);
				bbt_e=((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbObjectDowncast((bbt_)->clas->m_NextObject(bbt_),&bah_libcurl_curlmain_TCurlEasy));
				if(bbt_e==&bbNullObject){
					bbOnDebugLeaveScope();
					continue;
				}
				struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1575, 0};
				bbOnDebugEnterStm(&__stmt_0);
				if(bbt_ePtr==((struct bah_libcurl_curlmain_TCurlEasy_obj*)bbNullObjectTest(bbt_e))->_bah_libcurl_curlmain_tcurleasy_easyhandleptr ){
					struct BBDebugScope __scope = {
						BBDEBUGSCOPE_LOCALBLOCK,
						0,
						{
							BBDEBUGDECL_END 
						}
					};
					bbOnDebugEnterScope(&__scope);
					struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1576, 0};
					bbOnDebugEnterStm(&__stmt_0);
					((struct bah_libcurl_curlmain_TCurlMultiMsg_obj*)bbNullObjectTest(bbt_info))->_bah_libcurl_curlmain_tcurlmultimsg_easy =bbt_e;
					struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1577, 0};
					bbOnDebugEnterStm(&__stmt_1);
					bbOnDebugLeaveScope();
					bbOnDebugLeaveScope();
					break;
				}
				bbOnDebugLeaveScope();
			}
			struct BBDebugStm __stmt_5 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1581, 0};
			bbOnDebugEnterStm(&__stmt_5);
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			bbOnDebugLeaveScope();
			return bbt_info;
		}
		bbOnDebugLeaveScope();
	}
	struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1587, 0};
	bbOnDebugEnterStm(&__stmt_1);
	bbOnDebugLeaveScope();
	return &bbNullObject;
}
void _bah_libcurl_curlmain_TCurlMulti_multiSetOptInt_ii(struct bah_libcurl_curlmain_TCurlMulti_obj* o,BBINT bbt_option,BBINT bbt_parameter){
	((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o));
	struct BBDebugScope_3 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"multiSetOptInt",
		{
			{
				BBDEBUGDECL_LOCAL,
				"Self",
				":TCurlMulti",
				.var_address=&o
			},
			{
				BBDEBUGDECL_LOCAL,
				"option",
				"i",
				.var_address=&bbt_option
			},
			{
				BBDEBUGDECL_LOCAL,
				"parameter",
				"i",
				.var_address=&bbt_parameter
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1595, 0};
	bbOnDebugEnterStm(&__stmt_0);
	if(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ){
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_LOCALBLOCK,
			0,
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 1596, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bmx_curl_multi_setopt_long(((struct bah_libcurl_curlmain_TCurlMulti_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmulti_multihandleptr ,bbt_option,bbt_parameter);
		bbOnDebugLeaveScope();
	}
	bbOnDebugLeaveScope();
}
struct BBDebugScope_12 bah_libcurl_curlmain_TCurlMulti_scope ={
	BBDEBUGSCOPE_USERTYPE,
	"TCurlMulti",
	{
		{
			BBDEBUGDECL_FIELD,
			"multiHandlePtr",
			"*b",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlMulti_obj,_bah_libcurl_curlmain_tcurlmulti_multihandleptr)
		},
		{
			BBDEBUGDECL_FIELD,
			"easyHandles",
			":TList",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlMulti_obj,_bah_libcurl_curlmain_tcurlmulti_easyhandles)
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"New",
			"()",
			&_bah_libcurl_curlmain_TCurlMulti_New
		},
		{
			BBDEBUGDECL_TYPEFUNCTION,
			"Create",
			"():TCurlMulti",
			&bah_libcurl_curlmain_TCurlMulti_Create_TTCurlMulti
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"newEasy",
			"():TCurlEasy",
			&_bah_libcurl_curlmain_TCurlMulti_newEasy
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"multiAdd",
			"(:TCurlEasy)i",
			&_bah_libcurl_curlmain_TCurlMulti_multiAdd_TTCurlEasy
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"multiRemove",
			"(:TCurlEasy)i",
			&_bah_libcurl_curlmain_TCurlMulti_multiRemove_TTCurlEasy
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"multiPerform",
			"(i)i",
			&_bah_libcurl_curlmain_TCurlMulti_multiPerform_vi
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"multiSelect",
			"(d)i",
			&_bah_libcurl_curlmain_TCurlMulti_multiSelect_d
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"multiCleanup",
			"()",
			&_bah_libcurl_curlmain_TCurlMulti_multiCleanup
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"multiInfoRead",
			"(i):TCurlMultiMsg",
			&_bah_libcurl_curlmain_TCurlMulti_multiInfoRead_vi
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"multiSetOptInt",
			"(i,i)",
			&_bah_libcurl_curlmain_TCurlMulti_multiSetOptInt_ii
		},
		BBDEBUGDECL_END
	}
};
struct BBClass_bah_libcurl_curlmain_TCurlMulti bah_libcurl_curlmain_TCurlMulti={
	&bbObjectClass,
	bbObjectFree,
	&bah_libcurl_curlmain_TCurlMulti_scope,
	sizeof(struct bah_libcurl_curlmain_TCurlMulti_obj),
	_bah_libcurl_curlmain_TCurlMulti_New,
	_bah_libcurl_curlmain_TCurlMulti_Delete,
	bbObjectToString,
	bbObjectCompare,
	bbObjectSendMessage,
	0,
	0,
	offsetof(struct bah_libcurl_curlmain_TCurlMulti_obj,_bah_libcurl_curlmain_tcurlmulti_easyhandles) - sizeof(void*) + sizeof(struct brl_linkedlist_TList_obj*)
	,bah_libcurl_curlmain_TCurlMulti_Create_TTCurlMulti
	,_bah_libcurl_curlmain_TCurlMulti_newEasy
	,_bah_libcurl_curlmain_TCurlMulti_multiAdd_TTCurlEasy
	,_bah_libcurl_curlmain_TCurlMulti_multiRemove_TTCurlEasy
	,_bah_libcurl_curlmain_TCurlMulti_multiPerform_vi
	,_bah_libcurl_curlmain_TCurlMulti_multiSelect_d
	,_bah_libcurl_curlmain_TCurlMulti_multiCleanup
	,_bah_libcurl_curlmain_TCurlMulti_multiInfoRead_vi
	,_bah_libcurl_curlmain_TCurlMulti_multiSetOptInt_ii
};

void _bah_libcurl_curlmain_TCurlMultiMsg_New(struct bah_libcurl_curlmain_TCurlMultiMsg_obj* o) {
	bbObjectCtor(o);
	o->clas = (BBClass*)&bah_libcurl_curlmain_TCurlMultiMsg;
	((struct bah_libcurl_curlmain_TCurlMultiMsg_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmultimsg_message = 0;
	((struct bah_libcurl_curlmain_TCurlMultiMsg_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmultimsg_easy = &bbNullObject;
	((struct bah_libcurl_curlmain_TCurlMultiMsg_obj*)bbNullObjectTest(o))->_bah_libcurl_curlmain_tcurlmultimsg_result = 0;
}
struct BBDebugScope_4 bah_libcurl_curlmain_TCurlMultiMsg_scope ={
	BBDEBUGSCOPE_USERTYPE,
	"TCurlMultiMsg",
	{
		{
			BBDEBUGDECL_FIELD,
			"message",
			"i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlMultiMsg_obj,_bah_libcurl_curlmain_tcurlmultimsg_message)
		},
		{
			BBDEBUGDECL_FIELD,
			"easy",
			":TCurlEasy",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlMultiMsg_obj,_bah_libcurl_curlmain_tcurlmultimsg_easy)
		},
		{
			BBDEBUGDECL_FIELD,
			"result",
			"i",
			.field_offset=offsetof(struct bah_libcurl_curlmain_TCurlMultiMsg_obj,_bah_libcurl_curlmain_tcurlmultimsg_result)
		},
		{
			BBDEBUGDECL_TYPEMETHOD,
			"New",
			"()",
			&_bah_libcurl_curlmain_TCurlMultiMsg_New
		},
		BBDEBUGDECL_END
	}
};
struct BBClass_bah_libcurl_curlmain_TCurlMultiMsg bah_libcurl_curlmain_TCurlMultiMsg={
	&bbObjectClass,
	bbObjectFree,
	&bah_libcurl_curlmain_TCurlMultiMsg_scope,
	sizeof(struct bah_libcurl_curlmain_TCurlMultiMsg_obj),
	_bah_libcurl_curlmain_TCurlMultiMsg_New,
	bbObjectDtor,
	bbObjectToString,
	bbObjectCompare,
	bbObjectSendMessage,
	0,
	0,
	offsetof(struct bah_libcurl_curlmain_TCurlMultiMsg_obj,_bah_libcurl_curlmain_tcurlmultimsg_result) - sizeof(void*) + sizeof(BBINT)
};

BBINT bah_libcurl_curlmain_CurlGlobalInit(BBINT bbt_flags){
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"CurlGlobalInit",
		{
			{
				BBDEBUGDECL_LOCAL,
				"flags",
				"i",
				.var_address=&bbt_flags
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 48, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbOnDebugLeaveScope();
	return curl_global_init(bbt_flags);
}
BBSTRING bah_libcurl_curlmain_CurlError(BBINT bbt_errorCode){
	struct BBDebugScope_1 __scope = {
		BBDEBUGSCOPE_FUNCTION,
		"CurlError",
		{
			{
				BBDEBUGDECL_LOCAL,
				"errorCode",
				"i",
				.var_address=&bbt_errorCode
			},
			BBDEBUGDECL_END 
		}
	};
	bbOnDebugEnterScope(&__scope);
	struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Downloads/BlitzMax_win32_0.87.3.16/BlitzMax/mod/bah.mod/libcurl.mod/curlmain.bmx", 55, 0};
	bbOnDebugEnterStm(&__stmt_0);
	bbOnDebugLeaveScope();
	return bbStringFromCString(curl_easy_strerror(bbt_errorCode));
}
static int _bb_bah_libcurl_curlmain_inited = 0;
int _bb_bah_libcurl_curlmain(){
	if (!_bb_bah_libcurl_curlmain_inited) {
		_bb_bah_libcurl_curlmain_inited = 1;
		__bb_brl_blitz_blitz();
		__bb_brl_map_map();
		__bb_brl_stream_stream();
		__bb_brl_linkedlist_linkedlist();
		_bb_bah_libcurl_common();
		bbObjectRegisterType(&bah_libcurl_curlmain_TCurlHasLists);
		bbObjectRegisterType(&bah_libcurl_curlmain_TCurlEasy);
		bbObjectRegisterType(&bah_libcurl_curlmain_TCurlInt);
		bbObjectRegisterType(&bah_libcurl_curlmain_TCurlFormData);
		bbObjectRegisterType(&bah_libcurl_curlmain_TCurlInfo);
		bbObjectRegisterType(&bah_libcurl_curlmain_TCurlMulti);
		bbObjectRegisterType(&bah_libcurl_curlmain_TCurlMultiMsg);
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_FUNCTION,
			"curlmain",
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		bbOnDebugLeaveScope();
		return 0;
	}
	return 0;
}