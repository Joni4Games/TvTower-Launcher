#ifndef BAH_LIBCURL_COMMON_BMX_DEBUG_WIN32_X86_H
#define BAH_LIBCURL_COMMON_BMX_DEBUG_WIN32_X86_H

#include <brl.mod/blitz.mod/.bmx/blitz.bmx.debug.win32.x86.h>
#include <pub.mod/zlib.mod/.bmx/zlib.bmx.debug.win32.x86.h>
#include "source.bmx.debug.win32.x86.h"
#include "consts.bmx.debug.win32.x86.h"
int _bb_bah_libcurl_common();
extern BBINT curl_global_init(BBINT bbt_flags);
extern BBBYTE* curl_easy_init();
extern void curl_easy_setopt(BBBYTE* bbt_handle,BBINT bbt_option,BBBYTE* bbt_param);
extern BBINT curl_easy_perform(BBBYTE* bbt_handle);
extern void curl_easy_cleanup(BBBYTE* bbt_handle);
extern void curl_easy_reset(BBBYTE* bbt_handle);
extern BBBYTE* curl_easy_strerror(BBINT bbt_code);
extern void curl_slist_free_all(BBBYTE* bbt_slist);
extern BBBYTE* curl_easy_escape(BBBYTE* bbt_handle,BBBYTE* bbt_s,BBINT bbt_length);
extern void curl_free(BBBYTE* bbt_handle);
extern BBBYTE* curl_easy_unescape(BBBYTE* bbt_handle,BBBYTE* bbt_txt,BBINT bbt_inlength,BBINT* bbt_outlength);
extern BBBYTE* curl_slist_append(BBBYTE* bbt_slist,BBBYTE* bbt_Text);
extern BBBYTE* curl_multi_init();
extern void curl_multi_cleanup(BBBYTE* bbt_handle);
extern BBINT curl_multi_remove_handle(BBBYTE* bbt_handle,BBBYTE* bbt_easy);
extern BBINT curl_multi_add_handle(BBBYTE* bbt_handle,BBBYTE* bbt_easy);
extern BBINT curl_multi_perform(BBBYTE* bbt_handle,BBINT* bbt_running);
extern BBBYTE* curl_multi_info_read(BBBYTE* bbt_handle,BBINT* bbt_queuesize);
extern void bmx_curl_easy_setopt_long(BBBYTE* bbt_handle,BBINT bbt_option,BBINT bbt_param);
extern void bmx_curl_easy_setopt_str(BBBYTE* bbt_handle,BBINT bbt_option,BBBYTE* bbt_param);
extern void bmx_curl_easy_setopt_obj(BBBYTE* bbt_handle,BBINT bbt_option,BBOBJECT bbt_param);
extern void bmx_curl_easy_setopt_bbint64(BBBYTE* bbt_handle,BBINT bbt_option,BBLONG bbt_param);
extern BBBYTE* bmx_curl_new_httppostPtr();
extern void bmx_curl_formadd_name_content(BBBYTE* bbt_httppostPtr,BBBYTE* bbt_name,BBBYTE* bbt_content);
extern void bmx_curl_formadd_name_content_type(BBBYTE* bbt_httppostPtr,BBBYTE* bbt_name,BBBYTE* bbt_content,BBBYTE* bbt_t);
extern void bmx_curl_formadd_name_file(BBBYTE* bbt_httppostPtr,BBBYTE* bbt_name,BBBYTE* bbt_file,BBINT bbt_kind);
extern void bmx_curl_formadd_name_file_type(BBBYTE* bbt_httppostPtr,BBBYTE* bbt_name,BBBYTE* bbt_file,BBBYTE* bbt_t,BBINT bbt_kind);
extern void bmx_curl_formadd_name_buffer(BBBYTE* bbt_httppostPtr,BBBYTE* bbt_name,BBBYTE* bbt_bname,BBBYTE* bbt_buffer,BBINT bbt_length);
extern void bmx_curl_httppostPtr_delete(BBBYTE* bbt_httppostPtr);
extern void bmx_curl_easy_setopt_httppost(BBBYTE* bbt_handle,BBBYTE* bbt_httppostPtr);
extern BBINT bmx_curl_easy_getinfo_string(BBBYTE* bbt_handle,BBINT bbt_option,BBBYTE* bbt_b);
extern BBINT bmx_curl_easy_getinfo_long(BBBYTE* bbt_handle,BBINT bbt_option,BBINT* bbt_value);
extern BBINT bmx_curl_easy_getinfo_double(BBBYTE* bbt_handle,BBINT bbt_option,BBDOUBLE* bbt_value);
extern BBOBJECT bmx_curl_easy_getinfo_obj(BBBYTE* bbt_handle,BBINT bbt_option,BBINT* bbt_error);
extern BBBYTE* bmx_curl_easy_getinfo_slist(BBBYTE* bbt_handle,BBINT bbt_option,BBINT* bbt_error);
extern BBINT bmx_curl_multiselect(BBBYTE* bbt_handle,BBDOUBLE bbt_timeout);
extern BBINT bmx_curl_CURLMsg_msg(BBBYTE* bbt_handle);
extern BBINT bmx_curl_CURLMsg_result(BBBYTE* bbt_handle);
extern BBBYTE* bmx_curl_CURLMsg_easy_handle(BBBYTE* bbt_handle);
extern BBBYTE* bmx_curl_get_slist(BBBYTE* bbt_slist);
extern void bmx_curl_slist_free(BBBYTE* bbt_slist);
extern BBBYTE* bmx_curl_get_slist_data(BBBYTE* bbt_slist);
extern BBBYTE* bmx_curl_get_slist_next(BBBYTE* bbt_slist);
extern BBINT bmx_curl_slist_count(BBBYTE* bbt_slist);
extern BBBYTE* bmx_curl_slist_new();
extern void bmx_curl_add_element(BBBYTE* bbt_slist,BBBYTE* bbt_txt);
extern void bmx_curl_easy_setopt_slist(BBBYTE* bbt_handle,BBINT bbt_option,BBBYTE* bbt_slist);
extern void bmx_curl_multi_setopt_long(BBBYTE* bbt_handle,BBINT bbt_option,BBINT bbt_param);
BBARRAY bah_libcurl_common_curlProcessSlist(BBBYTE* bbt_slistPtr);

#endif
