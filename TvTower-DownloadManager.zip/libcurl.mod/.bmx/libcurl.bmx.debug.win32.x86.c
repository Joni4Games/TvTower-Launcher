#include <bah.mod/libcurl.mod/.bmx/libcurl.bmx.debug.win32.x86.h>
static int __bb_bah_libcurl_libcurl_inited = 0;
int __bb_bah_libcurl_libcurl(){
	if (!__bb_bah_libcurl_libcurl_inited) {
		__bb_bah_libcurl_libcurl_inited = 1;
		__bb_brl_blitz_blitz();
		_bb_bah_libcurl_curlmain();
		struct BBDebugScope __scope = {
			BBDEBUGSCOPE_FUNCTION,
			"libcurl",
			{
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		bbOnDebugLeaveScope();
		return 0;
	}
	return 0;
}