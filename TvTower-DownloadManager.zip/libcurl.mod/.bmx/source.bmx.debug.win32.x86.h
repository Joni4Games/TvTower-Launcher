#ifndef BAH_LIBCURL_SOURCE_BMX_DEBUG_WIN32_X86_H
#define BAH_LIBCURL_SOURCE_BMX_DEBUG_WIN32_X86_H

#include <brl.mod/blitz.mod/.bmx/blitz.bmx.debug.win32.x86.h>
int _bb_bah_libcurl_source();

#endif
