#include "ex_01.bmx.gui.debug.win32.x86.h"
static BBString _s0={
	&bbStringClass,
	21,
	{119,119,119,46,102,114,105,101,100,111,102,114,101,110,107,101,108
	,46,99,111,109}
};
struct BBDebugScope_2{int kind; const char *name; BBDebugDecl decls[3]; };
static int _bb_main_inited = 0;
int _bb_main(){
	if (!_bb_main_inited) {
		_bb_main_inited = 1;
		__bb_brl_blitz_blitz();
		__bb_bah_libcurl_libcurl();
		__bb_brl_standardio_standardio();
		struct bah_libcurl_curlmain_TCurlEasy_obj* volatile bbt_curl=&bbNullObject;
		BBINT bbt_res=0;
		struct BBDebugScope_2 __scope = {
			BBDEBUGSCOPE_FUNCTION,
			"ex_01",
			{
				{
					BBDEBUGDECL_LOCAL,
					"curl",
					":TCurlEasy",
					.var_address=&bbt_curl
				},
				{
					BBDEBUGDECL_LOCAL,
					"res",
					"i",
					.var_address=&bbt_res
				},
				BBDEBUGDECL_END 
			}
		};
		bbOnDebugEnterScope(&__scope);
		struct BBDebugStm __stmt_0 = {"C:/Users/Joni/Documents/MaxIDE/libcurl.mod/examples/ex_01.bmx", 10, 0};
		bbOnDebugEnterStm(&__stmt_0);
		bbt_curl=bah_libcurl_curlmain_TCurlEasy_Create_TTCurlEasy();
		struct BBDebugStm __stmt_1 = {"C:/Users/Joni/Documents/MaxIDE/libcurl.mod/examples/ex_01.bmx", 12, 0};
		bbOnDebugEnterStm(&__stmt_1);
		(bbt_curl)->clas->m_setOptInt_ii(bbt_curl,41,1);
		struct BBDebugStm __stmt_2 = {"C:/Users/Joni/Documents/MaxIDE/libcurl.mod/examples/ex_01.bmx", 13, 0};
		bbOnDebugEnterStm(&__stmt_2);
		(bbt_curl)->clas->m_setOptInt_ii(bbt_curl,52,1);
		struct BBDebugStm __stmt_3 = {"C:/Users/Joni/Documents/MaxIDE/libcurl.mod/examples/ex_01.bmx", 15, 0};
		bbOnDebugEnterStm(&__stmt_3);
		(bbt_curl)->clas->m_setOptString_iS(bbt_curl,10002,&_s0);
		struct BBDebugStm __stmt_4 = {"C:/Users/Joni/Documents/MaxIDE/libcurl.mod/examples/ex_01.bmx", 17, 0};
		bbOnDebugEnterStm(&__stmt_4);
		bbt_res=(bbt_curl)->clas->m_perform(bbt_curl);
		struct BBDebugStm __stmt_5 = {"C:/Users/Joni/Documents/MaxIDE/libcurl.mod/examples/ex_01.bmx", 19, 0};
		bbOnDebugEnterStm(&__stmt_5);
		(bbt_curl)->clas->m_cleanup(bbt_curl);
		bbOnDebugLeaveScope();
		return 0;
	}
	return 0;
}