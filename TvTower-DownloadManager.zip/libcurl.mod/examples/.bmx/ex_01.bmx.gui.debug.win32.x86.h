#ifndef EXAMPLES_EX_01_BMX_GUI_DEBUG_WIN32_X86_H
#define EXAMPLES_EX_01_BMX_GUI_DEBUG_WIN32_X86_H

#include <brl.mod/blitz.mod/.bmx/blitz.bmx.debug.win32.x86.h>
#include <bah.mod/libcurl.mod/.bmx/libcurl.bmx.debug.win32.x86.h>
#include <brl.mod/standardio.mod/.bmx/standardio.bmx.debug.win32.x86.h>
int _bb_main();

#endif
