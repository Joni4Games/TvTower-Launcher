import urllib
import time
import os.path
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

class Handler:
    def onDeleteWindow(self, *args):
        Gtk.main_quit(*args)

    def on_DownloadButton_pressed(self, DownloadButton):
        window.destroy()
        Gtk.main_quit()
    def on_StartButton_pressed(self, StartButton):
        window.destroy()
        Gtk.main_quit()

builder = Gtk.Builder()
builder.add_from_file("TvTower-Launcher.glade")
builder.connect_signals(Handler())

window = builder.get_object("window1")
window.set_size_request(600, 600)
window.set_title ("TvTower-Launcher")

DownloadButton = builder.get_object("DownloadButton")
StartButton = builder.get_object("StartButton")
window.show_all()



Gtk.main()
